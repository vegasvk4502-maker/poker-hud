package com.tacodawhale.pokerhud.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Everything remembered about each player, by username, kept across sessions: how many hands they were dealt,
 * how often they played (called or raised) and raised before the flop, and how often they raise after it.
 * A new username is a new player; a returning username picks up its history again.
 */
public final class PlayerBook {

    public static final class Player {
        public int id;
        public String name;
        public int hands, played, raised, postActions, postRaises;
        public long lastSeen;

        /** Share of hands they play (call or raise) before the flop. */
        public double playRate() { return hands == 0 ? 0 : played / (double) hands; }
        /** Share of hands they raise before the flop. */
        public double raiseRate() { return hands == 0 ? 0 : raised / (double) hands; }
        /** Share of their actions after the flop that are raises. */
        public double postRaiseRate() { return postActions == 0 ? 0 : postRaises / (double) postActions; }

        /** {type, how to play against them}. Needs a few hands before it says anything. */
        public String[] read() {
            if (hands < EARLY_READ_HANDS)
                return new String[]{"New", "no read yet (" + hands + " hands)"};
            double play = playRate(), raise = raiseRate(), post = postRaiseRate();
            boolean loose = play >= 0.35, tight = play < 0.22;
            boolean aggressive = raise >= 0.15 || (raise >= 0.10 && post >= 0.30);
            boolean passive = raise < 0.08;
            String type, tip;
            if (loose && aggressive) {
                type = "Maniac";
                tip = "raises a lot with weak hands – call them down lighter, let them bluff, trap with big hands";
            } else if (loose && passive) {
                type = "Calling station";
                tip = "calls too much – never bluff them, bet your good hands big";
            } else if (tight && aggressive) {
                type = "Solid";
                tip = "plays few hands but well – respect their raises, avoid bluffing them";
            } else if (tight) {
                type = "Rock";
                tip = "plays only strong hands – fold to their raises, steal their blinds";
            } else if (loose) {
                type = "Loose";
                tip = "plays lots of hands – value bet more, bluff less";
            } else {
                type = "Average";
                tip = "no big leak – play your normal game";
            }
            if (post >= 0.40 && postActions >= 6) tip += "; bluffs a lot after the flop";
            return new String[]{type, tip};
        }
    }

    /** Short version for the table map: {type, short tip}. */
    public static String[] shortRead(Player p) {
        String[] r = p.read();
        String t;
        switch (r[0]) {
            case "Rock": t = "fold to raises · steal blinds"; break;
            case "Solid": t = "respect raises · don't bluff"; break;
            case "Calling station": t = "never bluff · bet big"; break;
            case "Maniac": t = "call lighter · trap"; break;
            case "Loose": t = "value bet · bluff less"; break;
            case "Average": t = "play normal"; break;
            default: t = p.hands + (p.hands == 1 ? " hand" : " hands") + " so far";
        }
        if (isEarly(p)) t += " (early read, " + p.hands + " hands)";
        if (p.hands >= MIN_HANDS_FOR_READ && p.postRaiseRate() >= 0.40 && p.postActions >= 6) t += " · bluffs";
        return new String[]{r[0], t};
    }

    /** Colour for each player type (on the table map). */
    public static int typeColor(String type) {
        switch (type) {
            case "Rock": return 0xFF9FB4C8;
            case "Solid": return 0xFF5AA9FF;
            case "Calling station": return 0xFF4CFF6A;
            case "Maniac": return 0xFFFF5A4A;
            case "Loose": return 0xFFFFA43D;
            case "Average": return 0xFFFFFFFF;
            default: return 0xFFAAAAAA;
        }
    }

    /** Hands before a player gets a first (early) read, and before it's a full read. */
    public static final int EARLY_READ_HANDS = 3, MIN_HANDS_FOR_READ = 10;

    /** True while the read is based on only a few hands. */
    public static boolean isEarly(Player p) { return p.hands >= EARLY_READ_HANDS && p.hands < MIN_HANDS_FOR_READ; }

    /** Until a player has this many hands, the defaults count as much as their own history. */
    public static final int PRIOR_HANDS = 15;
    public static final int MAX_PLAYERS = 1000;

    /** Words the game shows on a name plate instead of a name – not players. */
    private static final String[] NOT_NAMES = {"DISCONNECTED", "SITTING OUT", "SIT OUT", "ALL IN", "ALL-IN", "FOLD",
            "CHECK", "CALL", "RAISE", "BET", "BIG BLIND", "SMALL BLIND", "WAITING", "AWAY", "EMPTY", "OPEN SEAT"};

    private final List<Player> players = new ArrayList<>();
    private int nextId = 1;

    public synchronized List<Player> all() { return new ArrayList<>(players); }

    /** Tidy what the text reader saw; null if it isn't a usable username. */
    public static String clean(String raw) {
        if (raw == null) return null;
        String s = raw.trim().split("\n")[0].trim().replaceAll("[^A-Za-z0-9_.\\- ]", "").trim();
        if (s.length() < 3) return null;
        String up = s.toUpperCase(Locale.US);
        for (String w : NOT_NAMES) if (up.equals(w) || up.startsWith(w + " ")) return null;
        return s;
    }

    /** Fold letters the reader commonly confuses (0/O, 1/l/I, 5/S…) so small misreads still match. */
    static String key(String name) {
        StringBuilder sb = new StringBuilder();
        for (char c : name.toLowerCase(Locale.US).toCharArray()) {
            switch (c) {
                case '0': sb.append('o'); break;
                case '1': case 'i': case '|': sb.append('l'); break;
                case '5': sb.append('s'); break;
                case '8': sb.append('b'); break;
                case ' ': break;
                default: sb.append(c);
            }
        }
        return sb.toString();
    }

    /**
     * The player with this username, or a new player. Every different username is a different player; only
     * look-alike characters the reader mixes up (0/O, 1/l/I, 5/S, 8/B, upper/lower case) are treated as the same.
     */
    public synchronized Player match(String name, long now) {
        String k = key(name);
        for (Player p : players) {
            if (key(p.name).equals(k)) { p.lastSeen = now; return p; }
        }
        Player p = new Player();
        p.id = nextId++;
        p.name = name;
        p.lastSeen = now;
        players.add(p);
        if (players.size() > MAX_PLAYERS) {   // forget whoever hasn't been seen for longest
            Player old = players.get(0);
            for (Player q : players) if (q.lastSeen < old.lastSeen) old = q;
            players.remove(old);
        }
        return p;
    }

    public synchronized Player byId(int id) {
        for (Player p : players) if (p.id == id) return p;
        return null;
    }

    /** Share of starting hands this player raises with (their history blended with the default). */
    public synchronized double raiseRange(int id) {
        Player p = byId(id);
        if (p == null) return Advisor.RAISER_RANGE;
        double r = (p.raised + PRIOR_HANDS * Advisor.RAISER_RANGE) / (p.hands + PRIOR_HANDS);
        return Math.max(0.04, Math.min(1.0, r));
    }

    /** Share of starting hands this player plays (calls or raises) with. */
    public synchronized double callRange(int id) {
        Player p = byId(id);
        if (p == null) return Advisor.CALLER_RANGE;
        double r = (p.played + PRIOR_HANDS * Advisor.CALLER_RANGE) / (p.hands + PRIOR_HANDS);
        return Math.max(0.08, Math.min(1.0, r));
    }

    public synchronized void clear() { players.clear(); nextId = 1; }

    // ---- save / load: one player per line, tab-separated, name last ----

    public synchronized String save() {
        StringBuilder sb = new StringBuilder("v2\t").append(nextId).append('\n');
        for (Player p : players) {
            sb.append(p.id).append('\t').append(p.hands).append('\t').append(p.played).append('\t').append(p.raised)
                    .append('\t').append(p.postActions).append('\t').append(p.postRaises).append('\t')
                    .append(p.lastSeen).append('\t').append(p.name).append('\n');
        }
        return sb.toString();
    }

    public synchronized void load(String s) {
        players.clear();
        nextId = 1;
        if (s == null || !s.startsWith("v2\t")) return;
        String[] lines = s.split("\n");
        try { nextId = Integer.parseInt(lines[0].split("\t")[1]); } catch (Exception ignored) { }
        for (int i = 1; i < lines.length; i++) {
            try {
                String[] t = lines[i].split("\t", 8);
                Player p = new Player();
                p.id = Integer.parseInt(t[0]);
                p.hands = Integer.parseInt(t[1]);
                p.played = Integer.parseInt(t[2]);
                p.raised = Integer.parseInt(t[3]);
                p.postActions = Integer.parseInt(t[4]);
                p.postRaises = Integer.parseInt(t[5]);
                p.lastSeen = Long.parseLong(t[6]);
                p.name = t[7];
                players.add(p);
                nextId = Math.max(nextId, p.id + 1);
            } catch (Exception ignored) { }
        }
    }
}
