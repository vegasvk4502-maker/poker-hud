package com.tacodawhale.pokerhud.core;

/**
 * Flush and straight draws: which unseen cards (outs) complete them, and the chance of hitting by the river.
 * Only counts cards that make the hand with at least one of your cards (not ones that just complete the board).
 */
public final class Draws {

    /** @return e.g. "Flush draw: 9 outs, 35% by the river", or "" when there's no draw (or it's already made). */
    public static String describe(int[] hero, int[] board) {
        int n = board.length;
        if (n < 3 || n > 4) return "";
        int[] all = new int[n + 2];
        System.arraycopy(board, 0, all, 0, n);
        all[n] = hero[0]; all[n + 1] = hero[1];
        int mine = HandEval.category(HandEval.eval(all, n + 2));
        boolean haveStraight = mine >= 4, haveFlush = mine == 5 || mine == 8;

        boolean[] seen = new boolean[52];
        for (int c : all) seen[c] = true;
        int unseen = 52 - all.length;

        int flushOuts = 0, straightOuts = 0, outs = 0;
        int[] withCard = new int[n + 3];
        System.arraycopy(all, 0, withCard, 0, n + 2);
        int[] boardWith = new int[n + 1];
        System.arraycopy(board, 0, boardWith, 0, n);
        for (int c = 0; c < 52; c++) {
            if (seen[c]) continue;
            withCard[n + 2] = c;
            boardWith[n] = c;
            int cat = HandEval.category(HandEval.eval(withCard, n + 3));
            int boardCat = HandEval.category(HandEval.eval(boardWith, n + 1));
            boolean flush = !haveFlush && (cat == 5 || cat == 8) && boardCat != 5 && boardCat != 8;
            boolean straight = !haveStraight && (cat == 4 || cat == 8) && boardCat != 4 && boardCat != 8;
            if (flush) flushOuts++;
            if (straight) straightOuts++;
            if (flush || straight) outs++;
        }
        if (outs == 0) return "";

        String name;
        if (flushOuts > 0 && straightOuts > 0) name = "Flush + straight draw";
        else if (flushOuts > 0) name = "Flush draw";
        else if (straightOuts >= 8) name = "Open-ended straight draw";
        else name = "Gutshot straight draw";

        double hit;
        if (n == 3) {   // two cards to come
            double miss = (unseen - outs) * (unseen - outs - 1) / (double) (unseen * (unseen - 1));
            hit = 1 - miss;
        } else {        // one card to come
            hit = outs / (double) unseen;
        }
        return name + ": " + outs + (outs == 1 ? " out, " : " outs, ") + Math.round(hit * 100) + "% "
                + (n == 3 ? "by the river" : "on the river");
    }
}
