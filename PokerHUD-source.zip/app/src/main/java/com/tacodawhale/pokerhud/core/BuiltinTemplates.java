package com.tacodawhale.pokerhud.core;

/** Rank glyphs captured from real screenshots of the game. */
final class BuiltinTemplates {
    static final String[] DATA = {
        "6:0.604:003e0007f000fe001fc001fc003f8007f8007f0007f000ffc01fff01fff83fffc3fffe7f8ff7f07ffe03ffe03ffc03ffe03ffe03ffe07f7f07f3fffe3fffc1fff80fff001fc0",
        "8:0.633:00f0007ff01fff83fffc3fffe7fffe7f0fe7f07f7f07f7f07e7f8fe3fffc1fffc0fff80fffc3fffc7f8fe7f07e7e03ffe03ffe03ffe03f7f07f7fffe7fffe3fffc1fff803fe0",
        "3:0.630:3fffc3fffc3fffc3fffc3fffc001f8003f0007e000fc001fc003fe007ff807ffc01ffe0007e0003f0003f0003f0001f0003f0003f1c07f3e07fffffe7fffc3fffc1fff807fe0",
        "A:0.804:01f8001f8001f8003fc003fe007fe007fe007fe007ff00fff00f9f00f9f00f9f81f9f81f9f81f0f81f0fc3f0fc3fffc3fffc3fffc7fffe7fffe7e07efc03efc03ffc03ff801f",
        "7:0.609:fffffffffffffffffffffffff000fe000fe000fc001fc003fc003f8007f8007f0007f000fe000fe001fe001fc001fc003f8003f8007f8007f000ff000fe000fc001fc001fc00",
        "9:0.586:03fc007ff01fff83fffc3fffe7f0fe7e07ffe03ffc03ffc03ffc03ffc03f7e03f7f07f3fffe3fffe1fffc07ffc03ffc003f8003f8007f0007f000fe000fe000fc001fc001f80",
        "4:0.638:0003e0007f000ff001ff001ff003fe007fe00ffe00ffe03ffe07efe07efe0fcfe1f8fe3f0fc7f0fcff0fcffffcffffffffffffffffffff007ff001fc001f8001f8003f8001f8",
        // from the AirDroid stream (smaller, video-compressed)
        "J:0.500:000ff000ff000ff000ff000ff000ff000ff000ff000ff000ff000ff000ff000ff000ff000ff000ff000ff000ff000ff000ff000ff001ff181ff3fffeffffcffffcffff83fff0",
        "J:0.500:000ff000ff000ff000ff000ff000ff000ff000ff000ff000ff000ff000ff000ff000ff000ff000ff000ff000ff000ff000ff000fe001fe101fe3fffeffffcffff8ffff01ff80",
        "Q:0.800:0070003ff007ff80fff81fffc3fffe3f87e3f07f3e03f7e03f7e03f7e01f7c01ffc01ffc01ffc19f7c3ff7e7ff7e7ff7e3fe7f1fe3f9fe3fffc1fffc0fffc0fffe03ffe0001c",
        "A:0.786:03f0003f0003f8007f8007f8007f8007fc00ffc00ffc00fbe00fbe00f3f01f3f01f1f01f1f01f0f81f0f81fff81fffc3fffc3fffe3fffe7ff7e7e03e7e03f7e03f7c01ffc00c",
        "6:0.600:002e0007f000fe001fe001fc003f8003f8007f000fe000ff001ffe03fff83fffc7fffe7f9fffe07ffc03ffc01ffc01ffc01ffc03ffc03ffe03f7fffe3fffe1fffc0fff807fe0",
        "3:0.636:3fffe3fffe3fffe3fffe3fffc003f8007f0007e000fc001f8003fc007ff803ffc031fe0007f0003f0003f0001f0001f0001f0001f0803f7e07fffffeffffe7fffc3fff81fff0",
        "4:0.667:001fc001fc003fc003fc007fc00ffc00ffc01ffc01ffc03dfc03cfc0fcfc0f8fc1f0fc1f0fc3e0fc7e0fcfe1fefffffffffffffffffffffffff000fc000fc000fc000fc000fc",
        "T:1.186:001f03c3f87c3fcfc3fcfc7fefc79e5cf0e1cf0e1cf0e1cf0f1cf071cf071cf071ef071ef071ef071ef071ef071ef071e7071e78f1e78e0e7de0e3fe0e3fe0e1fc0e0f80e070",
        "3:0.610:0fff80ffff0ffff1ffff0ffff000fe001fc003f000ff001fc003fe003ff801ffc001fe0007f0003f0003f0001f0001f0003f0003f7c07ffe0ffffffeffffc7fffc1fff007fc0",
        "K:0.762:7c1fcfc1f8fc3f87c3f07c7e07c7e07efc07efc07ffc07ff807ff007ff807ff807ffc07ffc07ffe07ffe07f7f07f3f87e3f87e1f87e0fc3e0fe3e07e3e07f3f03f3f03f3f010",
        "T:1.143:fe1f8fe3fcfc3fefc7fe3c7fe3cf9f3cf1f3cf0f3cf0f3df0f3df0f3df0f3df0f3de0f3de0f39e0f39e0f79e0f79e1f79e1f79f1e78f1e78f3e78ffe78ffc387fc003f8003f0",
        "2:0.600:00f8003fe00fff83fffe7fffefffffffffffe07f3807f0007f0007f000ff000fe001fe003fc007fc00ff001ff003fe007fc00ff801ff001ff007ffffffffffffffffffffffff",
        "5:0.571:07fe007fff0ffff0ffff0ffff0fc1e0fc000fc001f8001fff01fff81fffe3ffff1f8ff0603f0003f0003f0003f0003f0003f0803f7c07ffe0ffffffe7fffc3fff81fff007fc0",
        "5:0.600:1fffc3fffc3fffc3fffc3fffc3fffc7f0007f0007f0007fff07fff87fffe7ffff7ffff3f0ff1c07f0003f0003f0003f0003f0807f3c07f7f1ffffffeffffe7fffc3fff80ffe0",
    };
}
