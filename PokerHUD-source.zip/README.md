# Poker HUD

A see-through overlay for Android that reads your poker table and tells you
**FOLD**, **CALL** or **RAISE**. It's built for play-money games against bots,
and laid out for a Galaxy S25 (1080 × 2340, portrait).

## Install on your phone
1. On the phone, open this repo's **Releases**, then **latest**, and tap **PokerHUD.apk**.
   Direct link: `https://github.com/<your-username>/<this-repo>/releases/latest/download/PokerHUD.apk`
2. Open the download. If Android asks, allow installs from your browser ("Install unknown apps").
3. If Play Protect warns you, tap **More details**, then **Install anyway**. It warns because the app isn't from the Play Store.

Every push to `main` builds a new APK automatically (see the **Actions** tab).
New builds install over the old one.

## Use it
1. Open **Poker HUD** and tap **Start HUD**.
2. Allow **Display over other apps** if asked, then come back and tap Start again.
3. When Android asks what to share, choose **A single app** and pick the poker game.
   That keeps the panel itself out of the capture. **Entire screen** also works.
4. Switch to the game.

The panel shows:
- the action, plus your chance of winning against the players still in the hand
- your cards and the board
- your made hand, how many opponents are still in, and who is deciding (or **YOUR TURN**)

The panel starts in the bottom-right corner, below the game. Drag it anywhere; it remembers the spot.
Tap it to hide or show the bottom line (who's in and who's deciding). While it sits over a game button, that button
can't be tapped, so park it in an empty area.

Portrait and landscape both work. If the game itself only runs in portrait, it shows as an upright strip
in the middle when the phone is sideways, and the HUD reads that strip.

## Watching the game through AirDroid (or another mirroring app)
The HUD finds the game inside the screen by itself and locks onto the spot where the cards read best. It only
looks again if the reading goes bad for a few seconds (for example after you scroll or zoom the browser). It works even when it's shrunk inside a browser
window with black bars beside it. When you start the HUD, choose **A single app** and pick the
browser showing the stream. That way the panel doesn't cover any part of the table it reads.

## How it reads the table
- **Your cards:** the two cards above your name, bottom-left.
- **Board:** the five slots in the middle.
- **Suits come from colour:** blue = ♦, red = ♥, green = ♣, black = ♠.
- **Opponents:** each of the 5 other seats is checked for red card backs (still in the hand)
  and a red name plate or countdown bar (deciding). You never pick seats by hand.
- **Your turn:** the red countdown ring beside your cards, or the raise-size buttons, are showing.
  The action then gets a ▶ in front of it.
- **Raisers:** an orange RAISE label under a player changes what they're assumed to hold.
  Before the flop: one of the strongest 20% of starting hands. After the flop: top pair or an overpair,
  two pair or better, or a flush / straight draw (with 1 in 4 raises treated as a bluff).
- **Callers:** a green CALL label (told apart from CHECK by the shorter word) means a middling hand.
  Before the flop: one of the better half of starting hands. After the flop: any pair using their cards,
  a pocket pair, or a draw (with about 1 in 3 calls made with nothing). Checkers count as any two cards.
- **Danger warnings (amber strip):** "Flush possible", "Straight possible", "Board paired – full house
  possible", or "4 to a flush / straight" when one card completes it. Shown only when you don't already hold
  that kind of hand.
- **Position:** the gold dealer button tells it where you sit. Acting last (button / the seat before it)
  lowers the call and raise bars by 10%; acting first raises them by 12%; the blinds are slightly looser
  before the flop and slightly tighter after it. Your position is shown on the bottom line.
- **Starting-hand chart (★ strip, before the flop):** your two cards on the starting-hand chart, in the chart's
  own colours – dark green Premium (always raise), green Strong (raise), yellow Good (play unless you act early),
  orange Late only (play on / next to the button when nobody raised), grey Fold – plus what to do from your seat
  and the hand's raw strength (top / bottom %).
- **The nuts (gold on green, 🔒):** no two cards anyone could hold beat your hand right now.
- Danger warnings also include **"Higher flush / straight possible"** when you have a flush or straight
  but a bigger one is possible.
- **Draw info (teal strip, $):** flush and straight draws after the flop and turn, with the number of
  outs (unseen cards that complete it with one of your cards) and the chance of hitting by the river.
- **Traffic light:** green = your % is at or above what's needed to call, red = check or fold.
  Needed to call before the flop: 53% vs 1 opponent, 35% vs 2, 26% vs 3, 21% vs 4, 18% vs 5.
- **Advice:** a Monte-Carlo simulation of your hand against that many random hands.
  The bars for raising and calling rise with the number of opponents.
  The app can't see bet sizes, so FOLD means "check instead if checking is free".

## Players and the hand log
- **Players:** each opponent's username is read off their name plate with Google's on-device text reader
  (ML Kit, works offline). A new username is a new player; a returning username gets its history back,
  whatever seat it sits in. For every player it keeps, across sessions: hands dealt, how often they
  play (call or raise) and raise before the flop, and how often they raise after it. Once they've played a few
  hands, their raises and calls are judged by their own habits: someone who raises 40% of hands is assumed to
  raise with a much wider range than someone who raises 8%.
- **Table map:** tap the panel to open a small round table showing every player in the seat they really sit in,
  with their type and how to play them underneath (after 10 hands): Rock (fold to raises, steal blinds), Solid
  (respect raises), Calling station (never bluff, bet big), Maniac (call lighter, trap), Loose, or Average.
  A red dot marks players still in the hand. Tap again to close it.
- **Whole-hand memory:** what each player did earlier in the hand still counts later. A player who raised before
  the flop is still treated as strong after it, even when the game has cleared their RAISE label.
- **Hands:** a hand ends when all the cards clear off the table; the next deal starts a new one.
- **Hand log:** one line per hand you were dealt: time, position, your cards, the board, the last advice and %,
  how many opponents, and whether you folded. Open the app → **Share hand log** to send it as a spreadsheet.

## Teaching new ranks
It has learned every rank from real screenshots.
To fix it:
1. Open the app and look under **Teach cards**.
2. Tap the card corner and pick the right rank.

It remembers from then on.

## Adjusting positions
All screen positions are in
`app/src/main/java/com/tacodawhale/pokerhud/core/Layout.java`, in pixels of a
1080 × 2340 screenshot. Other screen sizes are scaled automatically.
