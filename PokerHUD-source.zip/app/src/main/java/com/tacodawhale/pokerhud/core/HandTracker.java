package com.tacodawhale.pokerhud.core;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Follows a hand from deal to end: who sat where (by username), what each player did before and after the flop,
 * and what the HUD advised. A hand ends when all the cards clear from the table (or you're dealt different cards);
 * then it updates each player's history in the {@link PlayerBook} and writes one line to the hand log.
 */
public final class HandTracker {

    /** Reads the username on a seat's name plate (the app plugs in a text reader); null if unreadable. */
    public interface NameReader {
        String read(Frame f, int[] box);
    }

    static final class SeatInfo {
        int playerId = -1;
        boolean dealt;           // seen holding cards this hand
        char pre = '-';          // strongest action before the flop: R > C > K
        char post = '-';         // strongest action after the flop
        int postActions, postRaises, lastCountedStreet = -1;
        String shown, shownMaybe;  // cards shown at showdown ("9s3d"), once read the same twice in a row
    }

    private final PlayerBook book;
    private NameReader nameReader;
    private int clearFrames;
    private final List<String> log;
    private final int maxLog;

    private boolean inHand;
    private int dealer = -1;
    private String heroCards = "", board = "";
    private boolean heroSeen, heroFolded;
    private int heroMissing, foldStreet = -1, position = -1;
    private SeatInfo[] seats = newSeats();
    private String lastAdvice = "", lastEquity = "", lastNeed = "", preflopAdvice = "";
    private HeroStats heroStats;
    private int lastOpp;
    private boolean dirty;

    public static final String LOG_HEADER =
            "time,position,your cards,board,advice,win %,needed %,opponents,result";

    public HandTracker(PlayerBook book, List<String> log, int maxLog) {
        this.book = book; this.log = log; this.maxLog = maxLog;
    }

    private static SeatInfo[] newSeats() {
        SeatInfo[] s = new SeatInfo[Layout.SEAT_PLATE.length];
        for (int i = 0; i < s.length; i++) s[i] = new SeatInfo();
        return s;
    }

    private static int strength(char a) { return a == 'R' ? 3 : a == 'C' ? 2 : a == 'K' ? 1 : 0; }

    public synchronized void setNameReader(NameReader r) { nameReader = r; }

    /** Where your own stats are kept (optional). */
    public synchronized void setHeroStats(HeroStats h) { heroStats = h; }

    /** Where a seat's username is: the top line of its name plate. */
    public static int[] nameBox(Viewport vp, int seat) {
        int[] p = Layout.SEAT_PLATE[seat];
        return vp.map(new int[]{p[0] + 4, p[1] + 2, p[0] + Layout.PLATE_W - 4, p[1] + 42});
    }

    /** True when player history or the log changed (time to save). */
    public synchronized boolean takeDirty() { boolean d = dirty; dirty = false; return d; }

    public synchronized void update(TableReader.State st, Frame f, Viewport vp, long now) {
        String hero = st.hero.size() == 2 ? st.hero.get(0).text() + st.hero.get(1).text() : "";
        boolean anyShown = false;
        for (TableReader.Card[] c : st.shown) if (c != null) anyShown = true;
        boolean anyCards = !hero.isEmpty() || !st.board.isEmpty() || st.opponentsInHand() > 0 || anyShown;
        // a hand ends when every card has cleared off the table (a couple of frames in a row, to skip blinks)
        if (!anyCards) {
            if (inHand && ++clearFrames >= 2) finishHand();
            return;
        }
        clearFrames = 0;
        // backup: you're holding different cards than before = a new hand (in case the clear was missed)
        if (inHand && !hero.isEmpty() && !heroCards.isEmpty() && !hero.equals(heroCards)) finishHand();
        if (!inHand) startHand(st);
        if (st.dealer >= 0) dealer = st.dealer;
        if (st.heroPosition() >= 0) position = st.heroPosition();

        // your cards / folding
        if (!hero.isEmpty()) { heroCards = hero; heroSeen = true; heroMissing = 0; }
        else if (heroSeen && !heroFolded && st.opponentsInHand() > 0 && ++heroMissing >= 3) {
            heroFolded = true;
            foldStreet = st.board.size();
        }
        if (!st.board.isEmpty()) {
            StringBuilder b = new StringBuilder();
            for (TableReader.Card c : st.board) b.append(c.text());
            if (b.length() >= board.length()) board = b.toString();
        }

        // each opponent: who they are and what they did
        int street = st.board.size();
        boolean readThisFrame = false;
        for (int i = 0; i < seats.length; i++) {
            // showdown: cards shown face up (must read the same on two frames, and only sure reads)
            TableReader.Card[] sh = st.shown[i];
            if (sh != null && seats[i].shown == null && sh[0].sure && sh[1].sure) {
                String c = sh[0].text() + sh[1].text();
                if (c.equals(seats[i].shownMaybe)) seats[i].shown = c; else seats[i].shownMaybe = c;
            }
            boolean active = st.seats[i] != TableReader.SeatStatus.EMPTY_OR_OUT || st.actions[i] != '-';
            if (!active) continue;
            SeatInfo s = seats[i];
            if (st.seats[i] != TableReader.SeatStatus.EMPTY_OR_OUT) s.dealt = true;
            if (s.playerId < 0 && nameReader != null && !readThisFrame) {
                readThisFrame = true;   // at most one name read per frame – keeps the HUD quick
                String name = PlayerBook.clean(nameReader.read(f, nameBox(vp, i)));
                if (name != null) s.playerId = book.match(name, now).id;
            }
            char a = st.actions[i];
            if (a == 'R' || a == 'C' || a == 'K') {
                if (street == 0) { if (strength(a) > strength(s.pre)) s.pre = a; }
                else {
                    if (strength(a) > strength(s.post)) s.post = a;
                    if (s.lastCountedStreet != street) {
                        s.lastCountedStreet = street;
                        s.postActions++;
                        if (a == 'R') s.postRaises++;
                    }
                }
            }
        }
    }

    private void startHand(TableReader.State st) {
        inHand = true;
        seats = newSeats();
        heroCards = ""; board = ""; heroSeen = false; heroFolded = false; heroMissing = 0; foldStreet = -1;
        position = -1; lastAdvice = ""; lastEquity = ""; lastNeed = ""; lastOpp = 0; preflopAdvice = "";
        if (st.dealer >= 0) dealer = st.dealer;
    }

    private void finishHand() {
        inHand = false;
        // player histories
        for (SeatInfo s : seats) {
            if (s.playerId < 0 || !s.dealt) continue;
            PlayerBook.Player p = book.byId(s.playerId);
            if (p == null) continue;
            synchronized (book) {
                if (s.shown != null) book.recordShown(s.playerId, s.shown, s.pre, (s.pre == 'R' ? 1 : 0) + s.postRaises);
                p.hands++;
                if (s.pre == 'C' || s.pre == 'R') p.played++;
                if (s.pre == 'R') p.raised++;
                p.postActions += s.postActions;
                p.postRaises += s.postRaises;
            }
        }
        // your own stats: you "played" the hand unless you folded before the flop
        if (heroSeen && heroStats != null)
            heroStats.record(position, !(heroFolded && foldStreet <= 0), preflopAdvice);
        // hand log (only hands you were dealt into)
        if (heroSeen) {
            String result = heroFolded ? "folded " + streetName(foldStreet) : "played to the end";
            String line = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(new Date()) + ","
                    + Advisor.positionName(position) + "," + heroCards + "," + board + "," + lastAdvice + ","
                    + lastEquity + "," + lastNeed + "," + lastOpp + "," + result;
            synchronized (log) {
                log.add(line);
                while (log.size() > maxLog) log.remove(0);
            }
        }
        dirty = true;
    }

    private static String streetName(int boardCards) {
        return boardCards <= 0 ? "pre-flop" : boardCards == 3 ? "on the flop" : boardCards == 4 ? "on the turn" : "on the river";
    }

    /** Remember the advice the HUD is showing (the last one before the hand ends goes in the log). */
    public synchronized void noteAdvice(Advisor.Advice a, int opponents) {
        if (board.isEmpty()) preflopAdvice = a.action;   // the advice before the flop, for your stats
        lastAdvice = a.action;
        lastEquity = String.valueOf(Math.round(a.equity * 100));
        lastNeed = String.valueOf(Math.round(a.callNeed * 100));
        lastOpp = opponents;
    }

    /** How many times each opponent seat has raised this hand (once per betting round the game shows RAISE). */
    public synchronized int[] seatRaises(TableReader.State st) {
        int[] r = new int[seats.length];
        for (int i = 0; i < seats.length; i++) {
            SeatInfo s = seats[i];
            r[i] = (s.pre == 'R' ? 1 : 0) + s.postRaises;
            // a raise showing right now that hasn't been counted yet
            if (st != null && st.actions[i] == 'R') {
                int street = st.board.size();
                if (street == 0 && s.pre != 'R') r[i]++;
                else if (street > 0 && s.lastCountedStreet != street) r[i]++;
            }
        }
        return r;
    }

    /** Player id for each opponent seat this hand (-1 if unknown / empty). */
    public synchronized int[] seatPlayers() {
        int[] ids = new int[seats.length];
        for (int i = 0; i < seats.length; i++) ids[i] = seats[i].playerId;
        return ids;
    }

    /**
     * For each opponent seat still holding cards: the share of starting hands they're assumed to hold
     * (from what they did before the flop and their history) and their action after the flop (2 raise, 1 call).
     */
    public synchronized void ranges(TableReader.State st, List<Double> preFrac, List<Integer> post,
                                    List<String> labels) {
        for (int i = 0; i < seats.length; i++) {
            if (st.seats[i] == TableReader.SeatStatus.EMPTY_OR_OUT) continue;
            SeatInfo s = seats[i];
            char pre = strength(st.actions[i]) > strength(s.pre) && st.board.isEmpty() ? st.actions[i] : s.pre;
            char pst = st.board.isEmpty() ? '-' : (strength(st.actions[i]) > strength(s.post) ? st.actions[i] : s.post);
            preFrac.add(pre == 'R' ? book.raiseRange(s.playerId) : pre == 'C' ? book.callRange(s.playerId) : 1.0);
            post.add(pst == 'R' ? 2 : pst == 'C' ? 1 : 0);
            String what = pst == 'R' ? "raised" : pst == 'C' ? "called" : pre == 'R' ? "raised pre" : pre == 'C' ? "called pre" : "";
            labels.add(Layout.SEAT_NAMES[i] + (what.isEmpty() ? "" : " (" + what + ")"));
        }
    }
}
