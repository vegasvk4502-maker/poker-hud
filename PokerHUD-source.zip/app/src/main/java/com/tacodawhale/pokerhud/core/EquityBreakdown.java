package com.tacodawhale.pokerhud.core;

import java.util.List;

/**
 * The detailed equity view: win / tie / lose, your chance against each opponent on their own, which hands beat
 * you most often, and how many of the next cards improve your hand.
 */
public final class EquityBreakdown {
    public double win, tie, lose;
    /** Your share against each opponent alone (same order as the ranges passed in). */
    public double[] perOpponent;
    /** Up to three hand kinds that beat you most, as {HandEval category, share of all hands} pairs. */
    public int[] loseCats = new int[0];
    public double[] loseShares = new double[0];
    /** Next card: how many of the unseen cards improve your hand, out of how many (0 / 0 = not applicable). */
    public int helps, unseen;

    public static EquityBreakdown compute(Advisor ad, List<TableReader.Card> hero, List<TableReader.Card> board,
                                          double[] preFrac, int[] post, int iters) {
        EquityBreakdown r = new EquityBreakdown();
        int[] h = {HandEval.parse(hero.get(0).text()), HandEval.parse(hero.get(1).text())};
        int[] b = new int[board.size()];
        for (int i = 0; i < b.length; i++) b[i] = HandEval.parse(board.get(i).text());
        int opp = Math.max(1, preFrac.length);
        int[] minScore = new int[opp], postRange = new int[opp];
        for (int i = 0; i < opp; i++) {
            double fr = i < preFrac.length ? preFrac[i] : 1.0;
            minScore[i] = fr >= 0.999 ? Integer.MIN_VALUE : Advisor.cutoff(fr);
            postRange[i] = b.length >= 3 && i < post.length ? post[i] : 0;
        }

        // everyone together
        Advisor.Stats st = new Advisor.Stats();
        ad.equity(h, b, minScore, postRange, iters, st);
        double n = iters;
        r.win = st.wins / n; r.tie = st.ties / n; r.lose = st.losses / n;

        // what beats you most
        Integer[] order = new Integer[9];
        for (int i = 0; i < 9; i++) order[i] = i;
        java.util.Arrays.sort(order, (x, y) -> st.loseTo[y] - st.loseTo[x]);
        int k = 0;
        while (k < 3 && st.loseTo[order[k]] > 0 && st.loseTo[order[k]] >= iters / 100) k++;
        r.loseCats = new int[k];
        r.loseShares = new double[k];
        for (int i = 0; i < k; i++) { r.loseCats[i] = order[i]; r.loseShares[i] = st.loseTo[order[i]] / n; }

        // each opponent on their own
        r.perOpponent = new double[opp];
        for (int i = 0; i < opp; i++) {
            r.perOpponent[i] = ad.equity(h, b, new int[]{minScore[i]}, new int[]{postRange[i]}, Math.max(1500, iters / 3));
        }

        // next card
        if (b.length == 3 || b.length == 4) {
            int[] all = new int[b.length + 3];
            System.arraycopy(b, 0, all, 0, b.length);
            all[b.length] = h[0]; all[b.length + 1] = h[1];
            int mine = HandEval.category(HandEval.eval(all, b.length + 2));
            int[] boardWith = new int[b.length + 1];
            System.arraycopy(b, 0, boardWith, 0, b.length);
            boolean[] seen = new boolean[52];
            for (int i = 0; i < b.length + 2; i++) seen[all[i]] = true;
            for (int c = 0; c < 52; c++) {
                if (seen[c]) continue;
                r.unseen++;
                all[b.length + 2] = c;
                boardWith[b.length] = c;
                int cat = HandEval.category(HandEval.eval(all, b.length + 3));
                int boardCat = HandEval.category(HandEval.eval(boardWith, b.length + 1));
                if (cat > mine && cat > boardCat) r.helps++;   // better hand, and not just the board improving
            }
        }
        return r;
    }

    /** Short name for a hand kind, e.g. "Two pair". */
    public static String catName(int cat) { return HandEval.NAMES[cat]; }
}
