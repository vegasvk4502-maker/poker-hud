package com.tacodawhale.pokerhud.core;

/**
 * The starting-hand chart (which two-card hands to play), as five groups:
 * P premium (always raise), S strong (raise), G good (play unless you're one of the first to act),
 * O only on / next to the dealer button when nobody has raised, F fold.
 */
public final class StartingHands {

    /**
     * Rows and columns go A K Q J 10 9 8 7 6 5 4 3 2. Above the diagonal = same suit, below = different suits,
     * the diagonal = pairs.
     */
    private static final String[] CHART = {
            // A K Q J T 9 8 7 6 5 4 3 2
            "PPSSGOOOOOOOO",   // A
            "PPSGGOFFFFFFF",   // K
            "SGPGGOFFFFFFF",   // Q
            "GOOPGOFFFFFFF",   // J
            "OOOOSOOFFFFFF",   // 10
            "OFFFFSOOFFFFF",   // 9
            "FFFFFFGOFFFFF",   // 8
            "FFFFFFFGOFFFF",   // 7
            "FFFFFFFFOOFFF",   // 6
            "FFFFFFFFFOOFF",   // 5
            "FFFFFFFFFFOFF",   // 4
            "FFFFFFFFFFFOF",   // 3
            "FFFFFFFFFFFFO",   // 2
    };

    /** Chart group for two cards (card = rank*4 + suit, rank 0 = two … 12 = ace). */
    public static char group(int c1, int c2) {
        int r1 = c1 >> 2, r2 = c2 >> 2;
        int hi = Math.max(r1, r2), lo = Math.min(r1, r2);
        int a = 12 - hi, b = 12 - lo;                 // chart index: 0 = A … 12 = 2
        boolean suited = (c1 & 3) == (c2 & 3);
        if (hi == lo) return CHART[a].charAt(a);
        return suited ? CHART[a].charAt(b) : CHART[b].charAt(a);
    }

    public static String groupName(char g) {
        switch (g) {
            case 'P': return "Premium";
            case 'S': return "Strong";
            case 'G': return "Good";
            case 'O': return "Late only";
            default: return "Fold";
        }
    }

    /** The chart's rule for each group, as in its legend. */
    public static String rule(char g) {
        switch (g) {
            case 'P': return "Premium: always raise";
            case 'S': return "Strong: raise";
            case 'G': return "Good: play if you're not one of the first to act";
            case 'O': return "Only on / next to the dealer button, nobody raised";
            default: return "Fold from any seat";
        }
    }

    /** The chart's colour for each group. */
    public static int color(char g) {
        switch (g) {
            case 'P': return 0xFF1F8A4C;   // dark green
            case 'S': return 0xFF4CAF50;   // green
            case 'G': return 0xFFC9A227;   // yellow
            case 'O': return 0xFFE07A2E;   // orange
            default: return 0xFF3A4440;    // grey
        }
    }

    /** What the chart says to do from your seat (position: 0 button … 5 cutoff, -1 unknown); "" for Fold. */
    public static String verdict(char g, int position, boolean someoneRaised) {
        boolean early = position == 3;
        boolean late = position == 0 || position == 5;
        switch (g) {
            case 'P': return "always raise";
            case 'S': return "raise";
            case 'G': return early ? "fold (early seat)" : "play";
            case 'O':
                if (someoneRaised) return "fold (raised)";
                if (position < 0) return "late seat only";
                return late ? "play (late seat)" : "fold (not late)";
            default: return "";
        }
    }

    /**
     * Raw strength of each of the 169 starting hands: the share of all starting hands that win at least as often
     * against one random hand (worked out ahead of time). Index: high*13+low for pairs / same suit,
     * low*13+high for different suits (ranks 0 = two … 12 = ace).
     */
    private static final int[] TOP_PERCENT = {48,100,100,98,99,97,92,86,78,69,59,50,34,94,36,96,94,95,93,91,82,74,67,55,44,29,92,86,25,88,89,87,85,81,71,63,53,41,27,90,83,78,15,84,80,79,75,70,61,49,38,21,90,84,79,72,8,76,73,68,64,58,47,35,23,89,83,77,72,65,5,66,62,57,51,45,32,19,81,79,74,68,62,57,4,56,52,43,37,28,16,76,72,69,64,59,53,45,3,42,39,31,22,13,65,65,61,58,52,46,40,35,3,33,25,18,10,60,55,54,51,46,41,35,30,24,2,20,14,8,50,46,42,40,36,36,27,23,16,14,2,11,7,39,34,31,28,27,25,19,15,12,10,9,1,6,26,20,18,15,17,12,12,9,6,5,4,4,1};

    /** How strong the hand is among all starting hands, e.g. 6 = top 6% (100 = the very worst). */
    public static int topPercent(int c1, int c2) {
        int r1 = c1 >> 2, r2 = c2 >> 2, hi = Math.max(r1, r2), lo = Math.min(r1, r2);
        boolean suited = (c1 & 3) == (c2 & 3);
        return TOP_PERCENT[(hi == lo || suited) ? hi * 13 + lo : lo * 13 + hi];
    }

    /** "top 6%" or, for weak hands, "bottom 20%". */
    public static String strengthText(int c1, int c2) {
        int t = topPercent(c1, c2);
        return t <= 50 ? "top " + t + "%" : "bottom " + (101 - t) + "%";
    }

    /** e.g. "A J same" / "9 4 diff" / "7 7". */
    public static String shortName(int c1, int c2) {
        String R = "23456789TJQKA";
        int r1 = c1 >> 2, r2 = c2 >> 2;
        int hi = Math.max(r1, r2), lo = Math.min(r1, r2);
        String h = R.charAt(hi) == 'T' ? "10" : String.valueOf(R.charAt(hi));
        String l = R.charAt(lo) == 'T' ? "10" : String.valueOf(R.charAt(lo));
        if (hi == lo) return h + " " + l;
        return h + " " + l + ((c1 & 3) == (c2 & 3) ? " same" : " diff");
    }
}
