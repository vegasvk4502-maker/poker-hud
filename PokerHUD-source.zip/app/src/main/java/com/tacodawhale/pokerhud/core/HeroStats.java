package com.tacodawhale.pokerhud.core;

/**
 * How YOU play, kept across sessions: how many hands you play (stay in to see the flop or win before it),
 * split by seat, and how often you went with the HUD's advice before the flop.
 * The game doesn't show your own action label, so it can't tell your raises from your calls.
 */
public final class HeroStats {
    public int hands, played;
    public final int[] posHands = new int[4], posPlayed = new int[4];   // early, middle, late, blinds
    public int advisedFold, playedAnyway;      // HUD said FOLD before the flop / you played it anyway
    public int advisedPlay, foldedAnyway;      // HUD said CALL or RAISE before the flop / you folded

    public static final int MIN_HANDS = 10;

    /** Seat group: 0 early, 1 middle, 2 late, 3 blinds (from position 0 button … 5 cutoff), -1 unknown. */
    public static int group(int position) {
        switch (position) {
            case 3: return 0;
            case 4: return 1;
            case 0: case 5: return 2;
            case 1: case 2: return 3;
            default: return -1;
        }
    }

    public synchronized void record(int position, boolean playedHand, String preflopAdvice) {
        hands++;
        if (playedHand) played++;
        int g = group(position);
        if (g >= 0) { posHands[g]++; if (playedHand) posPlayed[g]++; }
        if ("FOLD".equals(preflopAdvice)) { advisedFold++; if (playedHand) playedAnyway++; }
        else if ("CALL".equals(preflopAdvice) || "RAISE".equals(preflopAdvice)) { advisedPlay++; if (!playedHand) foldedAnyway++; }
    }

    public synchronized double playRate() { return hands == 0 ? 0 : played / (double) hands; }

    private double rate(int g) { return posHands[g] == 0 ? -1 : posPlayed[g] / (double) posHands[g]; }

    /** {your type, a tip}. */
    public synchronized String[] read() {
        if (hands < MIN_HANDS) return new String[]{"Learning you", hands + " hands so far"};
        double p = playRate();
        String type, tip;
        if (p < 0.15) { type = "Very tight"; tip = "you fold too much – play more hands from late seats"; }
        else if (p <= 0.30) { type = "Solid"; tip = "good range – keep it up"; }
        else if (p <= 0.40) { type = "A bit loose"; tip = "drop the weakest hands, especially from early seats"; }
        else { type = "Too loose"; tip = "you play too many hands – stick to the chart"; }
        double early = rate(0), late = rate(2);
        if (early >= 0 && late >= 0 && posHands[0] >= 5 && posHands[2] >= 5 && late <= early)
            tip += "; play more hands late than early";
        return new String[]{type, tip};
    }

    /** Short tip for the table map. */
    public synchronized String shortTip() {
        String t = read()[0];
        switch (t) {
            case "Very tight": return "play more hands late";
            case "Solid": return "good range \u00B7 keep it up";
            case "A bit loose": return "drop weak hands early";
            case "Too loose": return "stick to the chart";
            default: return hands + " hands so far";
        }
    }

    /** One line for the app, e.g. "play 24% of hands · early 12% · late 38% · followed the advice 81%". */
    public synchronized String summary() {
        StringBuilder sb = new StringBuilder();
        sb.append(hands).append(" hands · you play ").append(Math.round(playRate() * 100)).append("%");
        String[] names = {"early", "middle", "late", "blinds"};
        for (int g = 0; g < 4; g++) if (posHands[g] > 0)
            sb.append(" · ").append(names[g]).append(' ').append(Math.round(rate(g) * 100)).append('%');
        int asked = advisedFold + advisedPlay;
        if (asked > 0) sb.append(" · went with the advice ")
                .append(Math.round(100.0 * (asked - playedAnyway - foldedAnyway) / asked)).append('%');
        return sb.toString();
    }

    public synchronized String save() {
        StringBuilder sb = new StringBuilder("h1");
        int[] all = {hands, played, advisedFold, playedAnyway, advisedPlay, foldedAnyway};
        for (int v : all) sb.append(' ').append(v);
        for (int g = 0; g < 4; g++) sb.append(' ').append(posHands[g]).append(' ').append(posPlayed[g]);
        return sb.toString();
    }

    public synchronized void load(String s) {
        try {
            String[] t = s.trim().split(" ");
            if (!t[0].equals("h1")) return;
            hands = Integer.parseInt(t[1]); played = Integer.parseInt(t[2]);
            advisedFold = Integer.parseInt(t[3]); playedAnyway = Integer.parseInt(t[4]);
            advisedPlay = Integer.parseInt(t[5]); foldedAnyway = Integer.parseInt(t[6]);
            for (int g = 0; g < 4; g++) { posHands[g] = Integer.parseInt(t[7 + 2 * g]); posPlayed[g] = Integer.parseInt(t[8 + 2 * g]); }
        } catch (Exception ignored) { }
    }

    public synchronized void clear() {
        hands = played = advisedFold = playedAnyway = advisedPlay = foldedAnyway = 0;
        java.util.Arrays.fill(posHands, 0);
        java.util.Arrays.fill(posPlayed, 0);
    }
}
