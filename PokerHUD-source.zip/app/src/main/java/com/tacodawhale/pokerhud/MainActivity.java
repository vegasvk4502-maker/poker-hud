package com.tacodawhale.pokerhud;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.tacodawhale.pokerhud.core.Glyph;
import com.tacodawhale.pokerhud.core.Templates;

import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_CAPTURE = 11;
    private TextView status;
    private LinearLayout teachList, playerList;
    private TextView logSummary;

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private TextView label(String s, float sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(6), 0, dp(6));
        return t;
    }

    private Button button(String s, Runnable r) {
        Button b = new Button(this);
        b.setText(s);
        b.setOnClickListener(v -> r.run());
        return b;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(24), dp(18), dp(24));

        root.addView(label("Poker HUD", 26, true));
        root.addView(label("1. Tap Start and allow \"Display over other apps\" if asked.\n"
                + "2. When Android asks what to share, pick \"A single app\" and choose your poker game "
                + "(or Entire screen).\n"
                + "3. Open the game. The see-through panel shows FOLD / CALL / RAISE.\n\n"
                + "The panel starts in the bottom-right corner, below the game. Drag it anywhere – it remembers the spot. "
                + "Tap it to show more or less. Works in portrait and landscape.\n\n"
                + "If you share the entire screen, keep the panel off the table (for example at the very bottom, "
                + "below the game) – anything it covers can't be read.", 15, false));
        root.addView(button("Start HUD", this::start));
        root.addView(button("Stop HUD", () -> startService(
                new Intent(this, HudService.class).setAction(HudService.ACTION_STOP))));
        status = label("", 14, false);
        root.addView(status);

        root.addView(label("Teach cards", 20, true));
        root.addView(label("The HUD already knows every rank. If it ever sees a card it "
                + "isn't sure about, the card's corner appears below. Tap it and pick "
                + "the right rank once; it remembers.", 14, false));
        root.addView(button("Refresh list", this::refresh));
        teachList = new LinearLayout(this);
        teachList.setOrientation(LinearLayout.VERTICAL);
        root.addView(teachList);
        root.addView(button("Forget taught cards", () -> {
            HudState.forgetLearned(this);
            Toast.makeText(this, "Cleared. Restart the HUD to apply.", Toast.LENGTH_SHORT).show();
            refresh();
        }));

        root.addView(label("Hand log", 20, true));
        logSummary = label("", 14, false);
        root.addView(logSummary);
        root.addView(button("Share hand log (spreadsheet)", this::shareLog));

        root.addView(label("Players", 20, true));
        root.addView(label("Every player the HUD has seen, by username. A new username is a new player; when a "
                + "username comes back, its history comes back with it. "
                + "\"Plays\" = how often they call or raise before the flop, \"raises\" = how often they raise. "
                + "Their raises and calls are judged by these numbers once they've played a few hands.", 14, false));
        playerList = new LinearLayout(this);
        playerList.setOrientation(LinearLayout.VERTICAL);
        root.addView(playerList);
        root.addView(button("Forget all players and the hand log", () ->
                new AlertDialog.Builder(this)
                        .setMessage("Delete every player's history and the hand log?")
                        .setPositiveButton("Delete", (d, w) -> { HudState.clearHistory(this); refresh(); })
                        .setNegativeButton("Cancel", null)
                        .show()));

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 3);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow Poker HUD to display over other apps, then come back and tap Start.",
                    Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            return;
        }
        MediaProjectionManager mpm = getSystemService(MediaProjectionManager.class);
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override
    protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req, result, data);
        if (req != REQ_CAPTURE) return;
        if (result != RESULT_OK || data == null) {
            Toast.makeText(this, "Screen sharing is needed to read the table.", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent svc = new Intent(this, HudService.class)
                .putExtra(HudService.EXTRA_CODE, result)
                .putExtra(HudService.EXTRA_DATA, data);
        startForegroundService(svc);
        Toast.makeText(this, "HUD started – switch to your game.", Toast.LENGTH_SHORT).show();
    }

    private void shareLog() {
        Intent send = new Intent(Intent.ACTION_SEND)
                .setType("text/plain")
                .putExtra(Intent.EXTRA_SUBJECT, "Poker HUD hand log")
                .putExtra(Intent.EXTRA_TEXT, HudState.logCsv(this));
        startActivity(Intent.createChooser(send, "Share hand log"));
    }

    private void refreshHistory() {
        List<String> log = HudState.handLog(this);
        int n, raise = 0, call = 0, fold = 0, folded = 0;
        synchronized (log) {
            n = log.size();
            for (String l : log) {
                String[] f = l.split(",", -1);
                if (f.length < 9) continue;
                if (f[4].equals("RAISE")) raise++; else if (f[4].equals("CALL")) call++; else if (f[4].equals("FOLD")) fold++;
                if (f[8].startsWith("folded")) folded++;
            }
        }
        logSummary.setText(n == 0 ? "No hands logged yet."
                : n + " hands logged · last advice: " + raise + " raise, " + call + " call, " + fold + " fold · you folded "
                + folded + ". Share it with Claude to check how accurate the % is.");

        playerList.removeAllViews();
        List<com.tacodawhale.pokerhud.core.PlayerBook.Player> ps = HudState.book(this).all();
        ps.sort((a, b) -> b.hands - a.hands);
        if (ps.isEmpty()) { playerList.addView(label("No players yet.", 14, false)); return; }
        int shown = 0;
        for (com.tacodawhale.pokerhud.core.PlayerBook.Player p : ps) {
            if (shown++ >= 40) break;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(0, dp(6), 0, dp(6));
            String[] r = p.read();
            row.addView(label(p.name + "  \u2013  " + r[0], 16, true));
            row.addView(label("How to play them: " + r[1], 13, false));
            row.addView(label(p.hands + " hands · plays " + Math.round(p.playRate() * 100) + "% · raises "
                    + Math.round(p.raiseRate() * 100) + "% · raises after flop " + Math.round(p.postRaiseRate() * 100) + "%",
                    13, false));
            playerList.addView(row);
        }
    }

    private void refresh() {
        refreshHistory();
        status.setText((HudState.running ? "Running · " : "") + HudState.lastStatus
                + "\nTaught cards saved: " + HudState.learnedCount(this));
        teachList.removeAllViews();
        List<Glyph> unknown = HudState.unknownCopy();
        if (unknown.isEmpty()) {
            teachList.addView(label("Nothing to teach right now.", 14, false));
            return;
        }
        for (Glyph g : unknown) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, dp(6), 0, dp(6));
            ImageView iv = new ImageView(this);
            iv.setImageBitmap(HudState.glyphBitmap(g, 3));
            row.addView(iv);
            Templates.Match m = HudState.templates(this).match(g);
            TextView t = label("   Best guess: " + rankName(m.rank) + "  – tap to set", 15, false);
            row.addView(t);
            row.setOnClickListener(v -> pickRank(g));
            teachList.addView(row);
        }
    }

    private static String rankName(char r) { return r == 'T' ? "10" : String.valueOf(r); }

    private void pickRank(Glyph g) {
        String ranks = Templates.RANKS;
        String[] items = new String[ranks.length()];
        for (int i = 0; i < items.length; i++) items[i] = rankName(ranks.charAt(i));
        new AlertDialog.Builder(this)
                .setTitle("Which rank is this?")
                .setItems(items, (d, which) -> {
                    HudState.teach(this, g, ranks.charAt(which));
                    Toast.makeText(this, "Learned " + items[which], Toast.LENGTH_SHORT).show();
                    refresh();
                })
                .setNegativeButton("Skip", null)
                .show();
    }
}
