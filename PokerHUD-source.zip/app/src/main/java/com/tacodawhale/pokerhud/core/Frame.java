package com.tacodawhale.pokerhud.core;

/** A captured screen frame as packed ARGB ints, plus colour helpers. Platform independent. */
public final class Frame {
    public final int w, h;
    public final int[] px;

    public Frame(int w, int h, int[] px) {
        this.w = w; this.h = h; this.px = px;
    }

    public int get(int x, int y) {
        if (x < 0 || y < 0 || x >= w || y >= h) return 0;
        return px[y * w + x];
    }

    public static int r(int c) { return (c >> 16) & 0xff; }
    public static int g(int c) { return (c >> 8) & 0xff; }
    public static int b(int c) { return c & 0xff; }

    /** Value (brightness) 0..255. */
    public static int v(int c) { return Math.max(r(c), Math.max(g(c), b(c))); }

    /** Saturation 0..1. */
    public static float s(int c) {
        int mx = v(c), mn = Math.min(r(c), Math.min(g(c), b(c)));
        return mx == 0 ? 0f : (mx - mn) / (float) mx;
    }

    /** Clearly coloured ink (not black/grey). Uses absolute chroma so near-black pixels don't count. */
    public static boolean colored(int c) {
        int mx = v(c), mn = Math.min(r(c), Math.min(g(c), b(c)));
        return mx - mn > 25 && s(c) > 0.35f;
    }

    /** Hue in degrees 0..360. */
    public static float hue(int c) {
        int R = r(c), G = g(c), B = b(c);
        int mx = Math.max(R, Math.max(G, B)), mn = Math.min(R, Math.min(G, B));
        if (mx == mn) return 0f;
        float d = mx - mn, hh;
        if (mx == R) hh = ((G - B) / d) % 6f;
        else if (mx == G) hh = (B - R) / d + 2f;
        else hh = (R - G) / d + 4f;
        hh *= 60f;
        return hh < 0 ? hh + 360f : hh;
    }

    /** Is this pixel the bright red of a bot's card back / active name plate. */
    public static boolean isRed(int c, int minV) {
        float hh = hue(c);
        return (hh < 16 || hh > 344) && s(c) > 0.47f && v(c) >= minV;
    }
}
