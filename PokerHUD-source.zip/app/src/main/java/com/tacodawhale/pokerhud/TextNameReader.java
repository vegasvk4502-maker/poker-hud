package com.tacodawhale.pokerhud;

import android.graphics.Bitmap;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.tacodawhale.pokerhud.core.Frame;
import com.tacodawhale.pokerhud.core.HandTracker;

import java.util.concurrent.TimeUnit;

/**
 * Reads usernames off the name plates with Google's on-device text reader (ML Kit, no internet needed).
 * The name is cut out, enlarged 3x (small text reads much better that way) and read; the top line is the name.
 */
final class TextNameReader implements HandTracker.NameReader {
    private final TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);

    @Override
    public String read(Frame f, int[] box) {
        int w = box[2] - box[0], h = box[3] - box[1];
        if (w < 10 || h < 5) return null;
        int scale = 3;
        int[] px = new int[w * h];
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) px[y * w + x] = f.get(box[0] + x, box[1] + y);
        Bitmap small = Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888);
        Bitmap big = Bitmap.createScaledBitmap(small, w * scale, h * scale, true);
        small.recycle();
        try {
            Text t = Tasks.await(recognizer.process(InputImage.fromBitmap(big, 0)), 2, TimeUnit.SECONDS);
            String best = null;
            float bestTop = Float.MAX_VALUE;
            for (Text.TextBlock b : t.getTextBlocks()) for (Text.Line l : b.getLines()) {
                android.graphics.Rect r = l.getBoundingBox();
                float top = r == null ? 0 : r.top;
                if (top < bestTop) { bestTop = top; best = l.getText(); }   // the top line is the username
            }
            return best;
        } catch (Exception e) {
            return null;
        } finally {
            big.recycle();
        }
    }

    void close() { recognizer.close(); }
}
