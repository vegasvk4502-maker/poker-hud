package com.tacodawhale.pokerhud;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.tacodawhale.pokerhud.core.Advisor;
import com.tacodawhale.pokerhud.core.Danger;
import com.tacodawhale.pokerhud.core.Draws;
import com.tacodawhale.pokerhud.core.Frame;
import com.tacodawhale.pokerhud.core.HandEval;
import com.tacodawhale.pokerhud.core.Layout;
import com.tacodawhale.pokerhud.core.StartingHands;
import com.tacodawhale.pokerhud.core.TableReader;
import com.tacodawhale.pokerhud.core.Viewport;

import java.nio.ByteBuffer;

/** Captures the screen, reads the table and shows the see-through advice panel on top of the game. */
public class HudService extends Service {
    static final String EXTRA_CODE = "code", EXTRA_DATA = "data", ACTION_STOP = "com.tacodawhale.pokerhud.STOP";
    private static final String CHANNEL = "hud";
    private static final long FRAME_MS = 500;

    private MediaProjection projection;
    private volatile VirtualDisplay display;
    private volatile ImageReader reader;
    private HandlerThread thread;
    private Handler worker;
    private final Handler main = new Handler(Looper.getMainLooper());

    private WindowManager wm;
    private LinearLayout panel;
    private WindowManager.LayoutParams lp;
    private TextView tvAction, tvLight, tvChart, tvNuts, tvWarn, tvDraw, tvCards, tvInfo, tvNote;
    private GradientDrawable chartBg;
    private TableMapView tableMap;
    private boolean showPlayers;   // tap the panel to show / hide the player reads
    private boolean compact;

    private TableReader tableReader;
    private com.tacodawhale.pokerhud.core.HandTracker tracker;
    private TextNameReader nameReader;
    private final Advisor advisor = new Advisor();
    private String shownKey = "", pendingKey = "";
    private int pendingCount;
    private Advisor.Advice advice;

    private volatile int[] panelRect;      // where the HUD panel is on screen, ignored when finding the game
    private Viewport lock;                 // game area locked onto (where the table reads best)
    private int badFrames;                 // frames in a row where the locked area read poorly
    private long lastSearch;

    private byte[] bytes;
    private int[] argb;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || ACTION_STOP.equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if (projection != null) return START_NOT_STICKY;   // already running

        startForegroundNow();
        int code = intent.getIntExtra(EXTRA_CODE, 0);
        Intent data = Build.VERSION.SDK_INT >= 33
                ? intent.getParcelableExtra(EXTRA_DATA, Intent.class)
                : intent.getParcelableExtra(EXTRA_DATA);
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        projection = data == null ? null : mpm.getMediaProjection(code, data);
        if (projection == null) { stopSelf(); return START_NOT_STICKY; }
        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() { main.post(HudService.this::stopSelf); }
        }, main);

        tableReader = new TableReader(HudState.templates(this));
        tracker = HudState.tracker(this);
        nameReader = new TextNameReader();
        tracker.setNameReader(nameReader);
        thread = new HandlerThread("hud-capture");
        thread.start();
        worker = new Handler(thread.getLooper());

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        Rect bounds = wm.getMaximumWindowMetrics().getBounds();
        int w = bounds.width(), h = bounds.height();
        int dpi = getResources().getDisplayMetrics().densityDpi;
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2);
        display = projection.createVirtualDisplay("pokerhud", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, worker);

        showOverlay();
        HudState.running = true;
        worker.postDelayed(tick, 800);
        return START_NOT_STICKY;
    }

    private void startForegroundNow() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Poker HUD", NotificationManager.IMPORTANCE_LOW));
        PendingIntent stop = PendingIntent.getService(this, 1,
                new Intent(this, HudService.class).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE);
        PendingIntent open = PendingIntent.getActivity(this, 2,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setContentTitle("Poker HUD is running")
                .setContentText("Reading the table. Tap to open, or Stop.")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentIntent(open)
                .addAction(new Notification.Action.Builder(null, "Stop", stop).build())
                .setOngoing(true)
                .build();
        startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
    }

    // ---------- overlay ----------

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private TextView text(float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        t.setShadowLayer(3, 0, 1, 0xFF000000);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private void showOverlay() {
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(8), dp(4), dp(8), dp(5));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0x99000000);              // see-through black
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), 0x55FFFFFF);
        panel.setBackground(bg);

        tvAction = text(18, 0xFFFFFFFF, true);
        tvLight = text(13, 0xFFFFFFFF, true);
        tvLight.setVisibility(View.GONE);
        tvLight.setPadding(dp(10), 0, 0, 0);
        tvCards = text(13, 0xFFFFFFFF, false);
        tvInfo = text(11, 0xFFDDDDDD, false);
        tvNote = text(10, 0xFFBBBBBB, false);
        tvNote.setVisibility(View.GONE);
        // table map: every player in their seat with their type and tip (tap the panel to show / hide)
        tableMap = new TableMapView(this);
        tableMap.setVisibility(View.GONE);
        tvAction.setText("Poker HUD");
        tvCards.setText("Looking for the table…");
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(tvAction);
        top.addView(tvLight);
        panel.addView(top);
        // starting-hand chart (before the flop): strip in the chart's own colour for your hand's group
        tvChart = text(13, 0xFFFFFFFF, true);
        chartBg = new GradientDrawable();
        chartBg.setCornerRadius(dp(6));
        tvChart.setBackground(chartBg);
        tvChart.setPadding(dp(6), dp(1), dp(6), dp(2));
        tvChart.setVisibility(View.GONE);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        clp.topMargin = dp(2);
        panel.addView(tvChart, clp);
        // the nuts: gold on a dark green strip
        tvNuts = text(13, 0xFFFFD84A, true);
        GradientDrawable nbg = new GradientDrawable();
        nbg.setColor(0xCC0B4A1F);
        nbg.setCornerRadius(dp(6));
        tvNuts.setBackground(nbg);
        tvNuts.setPadding(dp(6), dp(1), dp(6), dp(2));
        tvNuts.setText("\uD83D\uDD12 You have the nuts \u2013 nobody can beat you right now");
        tvNuts.setVisibility(View.GONE);
        panel.addView(tvNuts);
        // danger warnings: bright amber on a dark orange strip so they stand out from the rest
        tvWarn = text(13, 0xFFFFC23D, true);
        GradientDrawable wbg = new GradientDrawable();
        wbg.setColor(0xCC6B2A00);
        wbg.setCornerRadius(dp(6));
        tvWarn.setBackground(wbg);
        tvWarn.setPadding(dp(6), dp(1), dp(6), dp(2));
        tvWarn.setVisibility(View.GONE);
        panel.addView(tvWarn);
        // draw info: bright teal on a dark teal strip, marked with $
        tvDraw = text(13, 0xFF3DEBFF, true);
        GradientDrawable dbg = new GradientDrawable();
        dbg.setColor(0xCC00444F);
        dbg.setCornerRadius(dp(6));
        tvDraw.setBackground(dbg);
        tvDraw.setPadding(dp(6), dp(1), dp(6), dp(2));
        tvDraw.setVisibility(View.GONE);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        dlp.topMargin = dp(2);
        panel.addView(tvDraw, dlp);
        panel.addView(tvCards);
        panel.addView(tvInfo);
        panel.addView(tvNote);
        panel.addView(tableMap, 0);   // on top, so it opens upwards above the advice

        lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        // starts in the bottom-right corner, below the game; wherever you drag it is remembered between runs
        lp.gravity = Gravity.BOTTOM | Gravity.END;
        SharedPreferences pos = getSharedPreferences("pokerhud", MODE_PRIVATE);
        lp.x = pos.getInt("panel_br_x", dp(2));
        lp.y = pos.getInt("panel_br_y", dp(4));
        panel.setOnTouchListener(new View.OnTouchListener() {
            float sx, sy; int ox, oy; boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = e.getRawX(); sy = e.getRawY(); ox = lp.x; oy = lp.y; moved = false; return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) (e.getRawX() - sx), dy = (int) (e.getRawY() - sy);
                        if (Math.abs(dx) + Math.abs(dy) > dp(6)) moved = true;
                        if (moved) {
                            lp.x = Math.max(0, ox - dx);   // anchored bottom-right, so directions flip
                            lp.y = Math.max(0, oy - dy);
                            wm.updateViewLayout(panel, lp);
                            panel.post(HudService.this::updatePanelRect);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (moved) {
                            getSharedPreferences("pokerhud", MODE_PRIVATE).edit()
                                    .putInt("panel_br_x", lp.x).putInt("panel_br_y", lp.y).apply();
                        } else {           // tap = show / hide the player reads
                            showPlayers = !showPlayers;
                            tableMap.setVisibility(showPlayers ? View.VISIBLE : View.GONE);
                        }
                        return true;
                }
                return false;
            }
        });
        wm.addView(panel, lp);
        panel.getViewTreeObserver().addOnGlobalLayoutListener(this::updatePanelRect);
    }

    private void updatePanelRect() {
        if (panel == null || !panel.isAttachedToWindow()) return;
        int[] loc = new int[2];
        panel.getLocationOnScreen(loc);
        panelRect = new int[]{loc[0], loc[1], loc[0] + panel.getWidth(), loc[1] + panel.getHeight()};
    }

    /** Phone rotated: resize the capture so it matches the new orientation. */
    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        Handler h = worker;
        if (h == null || wm == null) return;
        Rect b = wm.getMaximumWindowMetrics().getBounds();
        int w = b.width(), hh = b.height();
        int dpi = getResources().getDisplayMetrics().densityDpi;
        h.post(() -> {
            VirtualDisplay d = display;
            ImageReader old = reader;
            if (d == null || old == null || (old.getWidth() == w && old.getHeight() == hh)) return;
            try {
                ImageReader nr = ImageReader.newInstance(w, hh, PixelFormat.RGBA_8888, 2);
                d.resize(w, hh, dpi);
                d.setSurface(nr.getSurface());
                reader = nr;
                old.close();
            } catch (Exception ignored) { }
        });
    }

    // ---------- capture loop ----------

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            try {
                Image img = reader.acquireLatestImage();
                if (img != null) {
                    try { process(img); } finally { img.close(); }
                }
            } catch (Exception e) {
                post("Error", e.getClass().getSimpleName() + ": " + e.getMessage(), "", "", 0xFFFFFFFF);
            }
            if (worker != null) worker.postDelayed(this, FRAME_MS);
        }
    };

    private void process(Image img) {
        int w = img.getWidth(), h = img.getHeight();
        Image.Plane plane = img.getPlanes()[0];
        ByteBuffer buf = plane.getBuffer();
        int ps = plane.getPixelStride(), rs = plane.getRowStride();
        if (bytes == null || bytes.length < buf.remaining()) bytes = new byte[buf.remaining()];
        int n = buf.remaining();
        buf.get(bytes, 0, n);
        if (argb == null || argb.length != w * h) argb = new int[w * h];
        for (int y = 0; y < h; y++) {
            int row = y * rs, o = y * w;
            for (int x = 0; x < w; x++) {
                int i = row + x * ps;
                if (i + 2 >= n) break;
                argb[o + x] = 0xFF000000 | ((bytes[i] & 0xff) << 16) | ((bytes[i + 1] & 0xff) << 8) | (bytes[i + 2] & 0xff);
            }
        }
        Frame frame = new Frame(w, h, argb);
        boolean landscape = w > h;
        // Find the game inside the screen: full screen, or shrunk inside a browser / AirDroid window.
        // Find the game on screen and stay locked on it. Re-search only when the locked area stops reading well
        // for a few seconds (e.g. the browser was scrolled or zoomed), at most every 3 s.
        TableReader.State st = null;
        Viewport vp = lock;
        float lockQ = -1e9f;
        if (lock != null) {
            st = tableReader.read(frame, lock);
            lockQ = st.quality();
            if (lockQ >= 4) badFrames = 0; else badFrames++;
        }
        long now = System.currentTimeMillis();
        if ((lock == null || badFrames >= 6) && now - lastSearch > 3000) {
            lastSearch = now;
            Object[] r = Viewport.search(frame, panelRect, tableReader);
            float q = (Float) r[1];
            if (q >= 5f && q > lockQ) {          // only move to an area that reads the table better
                lock = (Viewport) r[0];
                vp = lock;
                st = tableReader.read(frame, lock);
                badFrames = 0;
            }
        }
        if (st == null) {
            if (vp == null) vp = Viewport.detect(frame, panelRect);
            st = tableReader.read(frame, vp);
        }
        for (TableReader.Card c : st.hero) if (!c.sure) HudState.addUnknown(c.glyph);
        for (TableReader.Card c : st.board) if (!c.sure) HudState.addUnknown(c.glyph);

        // remember who's who and what everyone did this hand; save player history / hand log when it changes
        tracker.update(st, frame, vp, System.currentTimeMillis());
        if (tracker.takeDirty()) HudState.save(this);
        java.util.List<Double> preL = new java.util.ArrayList<>();
        java.util.List<Integer> postL = new java.util.ArrayList<>();
        java.util.List<String> labels = new java.util.ArrayList<>();
        tracker.ranges(st, preL, postL, labels);
        updatePlayerReads(st);

        StringBuilder seats = new StringBuilder();
        int deciding = st.decidingSeat();
        StringBuilder inHand = new StringBuilder();
        for (String l : labels) { if (inHand.length() > 0) inHand.append(", "); inHand.append(l); }
        if (st.heroTurn) seats.append("YOUR TURN");
        else if (deciding >= 0) seats.append(Layout.SEAT_NAMES[deciding]).append(" deciding");
        seats.append(seats.length() > 0 ? " · " : "").append("In: ")
                .append(inHand.length() == 0 ? "nobody" : inHand);

        String board = cardsText(st.board);
        boolean boardOk = st.board.size() == 0 || st.board.size() >= 3;
        if (st.hero.size() != 2 || !boardOk) {
            pendingKey = ""; pendingCount = 0;
            String cards = st.hero.size() == 2 ? "You: " + cardsText(st.hero) : "No cards (folded or waiting)";
            if (st.hero.isEmpty() && st.board.isEmpty() && st.opponentsInHand() == 0)
                cards = lock == null ? "Looking for the table…" : "Waiting for the next hand…";
            post("—", cards + (board.isEmpty() ? "" : "  |  " + board), seats.toString(), "", 0xFFAAAAAA);
            HudState.lastStatus = cards;
            return;
        }

        int opp = Math.max(1, st.opponentsInHand());
        double[] pre = new double[opp];
        int[] post = new int[opp];
        java.util.Arrays.fill(pre, 1.0);
        for (int i = 0; i < Math.min(opp, preL.size()); i++) { pre[i] = preL.get(i); post[i] = postL.get(i); }
        int position = st.heroPosition();
        String key = cardsText(st.hero) + "|" + board + "|" + opp + "|" + java.util.Arrays.toString(pre)
                + java.util.Arrays.toString(post) + "|" + position;
        // wait for two identical reads so dealing animations don't flicker the advice
        if (key.equals(pendingKey)) pendingCount++; else { pendingKey = key; pendingCount = 1; }
        if (pendingCount >= 2 && !key.equals(shownKey)) {
            advice = advisor.advise(st.hero, st.board, pre, post, position, 8000);
            shownKey = key;
            tracker.noteAdvice(advice, opp);
        }
        if (advice == null || !key.equals(shownKey)) return;

        int color = advice.action.equals("RAISE") ? 0xFF4CFF6A : advice.action.equals("CALL") ? 0xFFFFD84A : 0xFFFF5A4A;
        String action = (st.heroTurn ? "\u25B6 " : "") + advice.action + " " + Math.round(advice.equity * 100) + "%";
        String cards = cardsText(st.hero) + (board.isEmpty() ? "  (pre-flop)" : "  |  " + board)
                + (advice.madeHand.isEmpty() ? "" : "  · " + advice.madeHand);
        String pos = Advisor.positionName(position);
        String info = "vs " + opp + (pos.isEmpty() ? "" : " · " + pos) + " · " + seats;
        String note = advice.note;
        // traffic light: green = your chance is enough to call, red = check or fold
        boolean go = advice.equity >= advice.callNeed;
        String light = (go ? "\u25CF CALL OK" : "\u25CF CHECK/FOLD")
                + " (need " + Math.round(advice.callNeed * 100) + "%)";
        int lightColor = go ? 0xFF35E05A : 0xFFFF4040;
        // danger warnings for hands the board makes possible that beat yours
        int[] hc = new int[2], bc = new int[st.board.size()];
        for (int i = 0; i < 2; i++) hc[i] = HandEval.parse(st.hero.get(i).text());
        for (int i = 0; i < bc.length; i++) bc[i] = HandEval.parse(st.board.get(i).text());
        java.util.List<String> dangers = Danger.warnings(hc, bc);
        StringBuilder warn = new StringBuilder();
        for (String d : dangers) warn.append(warn.length() > 0 ? "\n" : "").append("\u26A0 ").append(d);
        // draw info: outs and the chance of hitting
        String drawInfo = Draws.describe(hc, bc);
        String draw = drawInfo.isEmpty() ? "" : "$ " + drawInfo;
        boolean nuts = Danger.isNuts(hc, bc);
        // before the flop: where your hand sits on the starting-hand chart, and what to do from your seat
        if (bc.length == 0) {
            char g = StartingHands.group(hc[0], hc[1]);
            boolean raised = false;
            for (String l : labels) if (l.contains("raised")) raised = true;
            String v = StartingHands.verdict(g, position, raised);
            setChart("\u2605 " + StartingHands.shortName(hc[0], hc[1]) + " \u00B7 " + StartingHands.groupName(g)
                    + (v.isEmpty() ? "" : ": " + v) + " \u00B7 " + StartingHands.strengthText(hc[0], hc[1]),
                    StartingHands.color(g));
        } else setChart("", 0);
        post(action, light, lightColor, nuts, warn.toString(), draw, cards, info, note, color);
        HudState.lastStatus = advice.action + " " + Math.round(advice.equity * 100) + "% · " + cardsText(st.hero) + " " + board;
    }

    /** Fill the table map: each seat's player, type and tip; a red dot for players still in the hand. */
    private void updatePlayerReads(TableReader.State st) {
        int[] ids = tracker.seatPlayers();
        com.tacodawhale.pokerhud.core.PlayerBook book = HudState.book(this);
        final String[] n = new String[6], t = new String[6], tp = new String[6];
        final int[] col = new int[6];
        final boolean[] in = new boolean[6];
        String pos = Advisor.positionName(st.heroPosition());
        n[0] = "You";
        t[0] = pos.isEmpty() ? null : pos;
        col[0] = 0xFFFFD84A;
        for (int i = 0; i < ids.length; i++) {
            in[i + 1] = st.seats[i] != TableReader.SeatStatus.EMPTY_OR_OUT;
            if (ids[i] < 0) {
                if (in[i + 1]) { n[i + 1] = "?"; t[i + 1] = "reading name…"; col[i + 1] = 0xFFAAAAAA; }
                continue;
            }
            com.tacodawhale.pokerhud.core.PlayerBook.Player p = book.byId(ids[i]);
            if (p == null) continue;
            String[] r = com.tacodawhale.pokerhud.core.PlayerBook.shortRead(p);
            n[i + 1] = p.name;
            t[i + 1] = r[0];
            tp[i + 1] = r[1];
            col[i + 1] = com.tacodawhale.pokerhud.core.PlayerBook.typeColor(r[0]);
        }
        main.post(() -> {
            if (tableMap == null) return;
            System.arraycopy(n, 0, tableMap.names, 0, 6);
            System.arraycopy(t, 0, tableMap.tags, 0, 6);
            System.arraycopy(tp, 0, tableMap.tips, 0, 6);
            System.arraycopy(col, 0, tableMap.tagColors, 0, 6);
            System.arraycopy(in, 0, tableMap.inHand, 0, 6);
            tableMap.setVisibility(showPlayers ? View.VISIBLE : View.GONE);
            tableMap.invalidate();
        });
    }

    private static boolean found(TableReader.State st) {
        return !st.hero.isEmpty() || !st.board.isEmpty() || st.opponentsInHand() > 0;
    }

    private static String cardsText(java.util.List<TableReader.Card> cs) {
        StringBuilder sb = new StringBuilder();
        for (TableReader.Card c : cs) {
            if (sb.length() > 0) sb.append(' ');
            sb.append(c.pretty());
        }
        return sb.toString();
    }

    private void post(String action, String cards, String info, String note, int color) {
        post(action, "", 0, false, "", "", cards, info, note, color);
        setChart("", 0);
    }

    /** Show / hide the starting-hand chart strip (background = the chart colour of your hand's group). */
    private void setChart(String text, int bg) {
        main.post(() -> {
            if (tvChart == null) return;
            tvChart.setText(text);
            chartBg.setColor(bg);
            // dark text on the light yellow / green groups, white on the darker ones
            tvChart.setTextColor(bg == 0xFFC9A227 || bg == 0xFF4CAF50 ? 0xFF111111 : 0xFFFFFFFF);
            tvChart.setShadowLayer(bg == 0xFFC9A227 || bg == 0xFF4CAF50 ? 0 : 3, 0, 1, 0xFF000000);
            tvChart.setVisibility(text.isEmpty() ? View.GONE : View.VISIBLE);
        });
    }

    private void post(String action, String light, int lightColor, boolean nuts, String warn, String draw,
                      String cards, String info, String note, int color) {
        main.post(() -> {
            if (panel == null) return;
            tvNuts.setVisibility(nuts ? View.VISIBLE : View.GONE);
            tvDraw.setText(draw);
            tvDraw.setVisibility(draw.isEmpty() ? View.GONE : View.VISIBLE);
            tvWarn.setText(warn);
            tvWarn.setVisibility(warn.isEmpty() ? View.GONE : View.VISIBLE);
            tvLight.setText(light);
            tvLight.setTextColor(lightColor);
            tvLight.setVisibility(light.isEmpty() ? View.GONE : View.VISIBLE);
            tvAction.setText(action);
            tvAction.setTextColor(color);
            tvCards.setText(cards);
            tvInfo.setText(info);
            tvNote.setText(note);
            tvInfo.setVisibility(compact || info.isEmpty() ? View.GONE : View.VISIBLE);
            tvNote.setVisibility(View.GONE);
        // table map: every player in their seat with their type and tip (tap the panel to show / hide)
        tableMap = new TableMapView(this);
        tableMap.setVisibility(View.GONE);   // kept small: the light already says call or not
        });
    }

    @Override
    public void onDestroy() {
        HudState.running = false;
        HudState.lastStatus = "HUD stopped";
        if (panel != null && wm != null) { try { wm.removeView(panel); } catch (Exception ignored) { } panel = null; }
        final VirtualDisplay d = display; final ImageReader r = reader;
        display = null; reader = null;
        if (worker != null) {
            Handler h = worker;
            worker = null;                       // stops the loop from re-posting
            h.removeCallbacksAndMessages(null);
            h.post(() -> {                       // release on the capture thread, after any frame in progress
                if (d != null) d.release();
                if (r != null) r.close();
            });
        }
        if (thread != null) thread.quitSafely();
        if (projection != null) { try { projection.stop(); } catch (Exception ignored) { } projection = null; }
        if (tracker != null) tracker.setNameReader(null);
        if (nameReader != null) { try { nameReader.close(); } catch (Exception ignored) { } nameReader = null; }
        super.onDestroy();
    }
}
