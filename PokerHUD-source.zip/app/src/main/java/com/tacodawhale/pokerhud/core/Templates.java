package com.tacodawhale.pokerhud.core;

import java.util.ArrayList;
import java.util.List;

/** Known rank glyphs: built-in ones from real screenshots, ones you taught, and font-rendered fallbacks. */
public final class Templates {
    public static final String RANKS = "23456789TJQKA";

    static final class T {
        final char rank; final Glyph g; final boolean synthetic;
        T(char r, Glyph g, boolean s) { rank = r; this.g = g; synthetic = s; }
    }

    private final List<T> list = new ArrayList<>();

    public synchronized void add(char rank, Glyph g, boolean synthetic) {
        list.add(new T(rank, g, synthetic));
    }

    public synchronized int size() { return list.size(); }

    public static final class Match {
        public final char rank; public final float score; public final float margin; public final boolean synthetic;
        Match(char r, float s, float m, boolean syn) { rank = r; score = s; margin = m; synthetic = syn; }
        /** Good enough to trust without asking you. */
        public boolean confident() {
            return synthetic ? (score > 0.80f && margin > 0.05f) : (score > 0.68f && margin > 0.02f);
        }
    }

    public synchronized Match match(Glyph g) {
        float best = -9, second = -9; char br = '?'; boolean bs = false;
        // best score per rank, so several samples of one rank don't eat the margin
        float[] perRank = new float[RANKS.length()];
        boolean[] synthOnly = new boolean[RANKS.length()];
        java.util.Arrays.fill(perRank, -9);
        java.util.Arrays.fill(synthOnly, true);
        for (T t : list) {
            int i = RANKS.indexOf(t.rank);
            float s = t.g.similarity(g) - (t.synthetic ? 0.03f : 0f);
            if (s > perRank[i]) { perRank[i] = s; synthOnly[i] = t.synthetic; }
        }
        for (int i = 0; i < perRank.length; i++) {
            float s = perRank[i];
            if (s > best) { second = best; best = s; br = RANKS.charAt(i); bs = synthOnly[i]; }
            else if (s > second) second = s;
        }
        return new Match(br, best, best - second, bs);
    }

    public void loadBuiltins() {
        for (String line : BuiltinTemplates.DATA) {
            add(line.charAt(0), Glyph.decode(line.substring(2)), false);
        }
    }
}
