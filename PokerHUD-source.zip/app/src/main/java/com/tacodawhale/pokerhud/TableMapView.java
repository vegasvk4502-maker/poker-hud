package com.tacodawhale.pokerhud;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.TypedValue;
import android.view.View;

/**
 * A small round table with every player sitting where they really sit, their name and, under it,
 * their type and how to play them. Shown when you tap the HUD panel.
 */
final class TableMapView extends View {
    /**
     * Where each seat's name goes on the map (fractions of the map's width / height), in the same places as on
     * the real table: you (bottom-left), Left, Top-left, Top, Top-right, Right.
     */
    private static final float[][] SEAT = {
            {0.24f, 0.88f}, {0.17f, 0.58f}, {0.17f, 0.30f}, {0.50f, 0.07f}, {0.83f, 0.30f}, {0.83f, 0.58f}};

    final String[] names = new String[6], tags = new String[6], tips = new String[6];
    final int[] tagColors = new int[6];
    final boolean[] inHand = new boolean[6];

    private final Paint felt = new Paint(Paint.ANTI_ALIAS_FLAG), rim = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint name = new Paint(Paint.ANTI_ALIAS_FLAG), tag = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tip = new Paint(Paint.ANTI_ALIAS_FLAG), dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float dp;

    TableMapView(Context c) {
        super(c);
        dp = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 1, c.getResources().getDisplayMetrics());
        felt.setColor(0xCC3A1414);
        rim.setColor(0xFF6E6E6E);
        rim.setStyle(Paint.Style.STROKE);
        rim.setStrokeWidth(3 * dp);
        name.setColor(0xFFFFFFFF);
        name.setTextSize(12 * dp);
        name.setTypeface(Typeface.DEFAULT_BOLD);
        name.setTextAlign(Paint.Align.CENTER);
        name.setShadowLayer(3, 0, 1, 0xFF000000);
        tag.setTextSize(11 * dp);
        tag.setTypeface(Typeface.DEFAULT_BOLD);
        tag.setTextAlign(Paint.Align.CENTER);
        tag.setShadowLayer(3, 0, 1, 0xFF000000);
        tip.setColor(0xFFDDDDDD);
        tip.setTextSize(9.5f * dp);
        tip.setTextAlign(Paint.Align.CENTER);
        tip.setShadowLayer(3, 0, 1, 0xFF000000);
        dot.setColor(0xFFE84A3A);
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        setMeasuredDimension((int) (360 * dp), (int) (300 * dp));
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        RectF table = new RectF(w * 0.33f, h * 0.24f, w * 0.67f, h * 0.80f);
        c.drawOval(table, felt);
        c.drawOval(table, rim);
        for (int i = 0; i < 6; i++) {
            if (names[i] == null) continue;
            float x = w * SEAT[i][0], y = h * SEAT[i][1];
            float half = Math.max(name.measureText(names[i]),
                    tips[i] == null ? 0 : tip.measureText(tips[i])) / 2 + 2 * dp;   // keep the text inside the box
            x = Math.max(half, Math.min(w - half, x));
            if (inHand[i]) c.drawCircle(x - name.measureText(names[i]) / 2 - 6 * dp, y - 4 * dp, 3 * dp, dot);
            boolean empty = "empty".equals(names[i]);
            name.setColor(empty ? 0xFF777777 : 0xFFFFFFFF);
            c.drawText(names[i], x, y, name);
            if (tags[i] != null) {
                tag.setColor(tagColors[i]);
                c.drawText(tags[i], x, y + 13 * dp, tag);
            }
            if (tips[i] != null) c.drawText(tips[i], x, y + 25 * dp, tip);
        }
    }
}
