package com.tacodawhale.pokerhud;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;

import com.tacodawhale.pokerhud.core.Glyph;
import com.tacodawhale.pokerhud.core.HandTracker;
import com.tacodawhale.pokerhud.core.PlayerBook;
import com.tacodawhale.pokerhud.core.Templates;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Shared between the overlay service and the app screen: rank templates and cards waiting to be taught. */
final class HudState {
    private static final String PREFS = "pokerhud", KEY_LEARNED = "learned";
    private static Templates templates;
    private static final List<Glyph> unknown = new ArrayList<>();
    static volatile String lastStatus = "HUD not running";
    static volatile boolean running;

    // ---- player history + hand log (kept between sessions) ----
    private static final String KEY_PLAYERS = "players", KEY_LOG = "hand_log";
    static final int MAX_LOG = 2000;
    private static PlayerBook book;
    private static List<String> handLog;
    private static HandTracker tracker;

    static synchronized PlayerBook book(Context c) {
        if (book == null) {
            book = new PlayerBook();
            book.load(prefs(c).getString(KEY_PLAYERS, ""));
        }
        return book;
    }

    static synchronized List<String> handLog(Context c) {
        if (handLog == null) {
            handLog = java.util.Collections.synchronizedList(new ArrayList<>());
            String s = prefs(c).getString(KEY_LOG, "");
            if (!s.isEmpty()) for (String line : s.split("\n")) if (!line.isEmpty()) handLog.add(line);
        }
        return handLog;
    }

    static synchronized HandTracker tracker(Context c) {
        if (tracker == null) tracker = new HandTracker(book(c), handLog(c), MAX_LOG);
        return tracker;
    }

    static void save(Context c) {
        StringBuilder sb = new StringBuilder();
        List<String> log = handLog(c);
        synchronized (log) { for (String l : log) sb.append(l).append('\n'); }
        prefs(c).edit().putString(KEY_PLAYERS, book(c).save()).putString(KEY_LOG, sb.toString()).apply();
    }

    static void clearHistory(Context c) {
        book(c).clear();
        handLog(c).clear();
        save(c);
    }

    /** The hand log as a CSV file's text, ready to share. */
    static String logCsv(Context c) {
        StringBuilder sb = new StringBuilder(HandTracker.LOG_HEADER).append('\n');
        List<String> log = handLog(c);
        synchronized (log) { for (String l : log) sb.append(l).append('\n'); }
        return sb.toString();
    }


    static synchronized Templates templates(Context c) {
        if (templates == null) {
            templates = new Templates();
            templates.loadBuiltins();
            for (String s : prefs(c).getStringSet(KEY_LEARNED, new HashSet<>())) {
                try { templates.add(s.charAt(0), Glyph.decode(s.substring(2)), false); } catch (Exception ignored) { }
            }
            addFontFallbacks(templates);
        }
        return templates;
    }

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /** Rank glyphs drawn with the phone's bold font – rough stand-ins until real ones are taught. */
    private static void addFontFallbacks(Templates t) {
        int W = 160, H = 120;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.BLACK);
        p.setTextSize(90);
        p.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
        for (char r : Templates.RANKS.toCharArray()) {
            Bitmap bm = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
            Canvas cv = new Canvas(bm);
            cv.drawColor(Color.WHITE);
            cv.drawText(r == 'T' ? "10" : String.valueOf(r), 10, 100, p);
            int[] px = new int[W * H];
            bm.getPixels(px, 0, W, 0, 0, W, H);
            boolean[] m = new boolean[W * H];
            for (int i = 0; i < m.length; i++) m[i] = (px[i] & 0xff) < 128;
            Glyph g = Glyph.fromMask(m, W, H);
            if (g != null) t.add(r, g, true);
            bm.recycle();
        }
    }

    static synchronized void addUnknown(Glyph g) {
        for (Glyph u : unknown) if (u.similarity(g) > 0.93f) return;
        if (unknown.size() >= 24) unknown.remove(0);
        unknown.add(g);
    }

    static synchronized List<Glyph> unknownCopy() { return new ArrayList<>(unknown); }

    static synchronized void teach(Context c, Glyph g, char rank) {
        templates(c).add(rank, g, false);
        unknown.remove(g);
        SharedPreferences p = prefs(c);
        Set<String> set = new HashSet<>(p.getStringSet(KEY_LEARNED, new HashSet<>()));
        set.add(rank + ":" + g.encode());
        p.edit().putStringSet(KEY_LEARNED, set).apply();
    }

    static synchronized void forgetLearned(Context c) {
        prefs(c).edit().remove(KEY_LEARNED).apply();
        templates = null;
        unknown.clear();
    }

    static synchronized int learnedCount(Context c) {
        return prefs(c).getStringSet(KEY_LEARNED, new HashSet<>()).size();
    }

    static Bitmap glyphBitmap(Glyph g, int scale) {
        Bitmap bm = Bitmap.createBitmap(Glyph.GW * scale, Glyph.GH * scale, Bitmap.Config.ARGB_8888);
        for (int y = 0; y < Glyph.GH * scale; y++)
            for (int x = 0; x < Glyph.GW * scale; x++)
                bm.setPixel(x, y, g.bits[(y / scale) * Glyph.GW + x / scale] ? Color.BLACK : Color.WHITE);
        return bm;
    }
}
