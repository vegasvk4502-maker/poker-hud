package com.tacodawhale.pokerhud.core;

/** Fast 5–7 card hand evaluator. Card = rank*4 + suit, rank 0 (two) .. 12 (ace). Higher score wins. */
public final class HandEval {
    public static final String[] NAMES = {"High card", "Pair", "Two pair", "Three of a kind", "Straight",
            "Flush", "Full house", "Four of a kind", "Straight flush"};

    public static int parse(String s) {
        int r = Templates.RANKS.indexOf(Character.toUpperCase(s.charAt(0)));
        int su = "shdc".indexOf(Character.toLowerCase(s.charAt(1)));
        return r * 4 + su;
    }

    public static int category(int score) { return score >>> 20; }

    private static int straightTop(int mask) {
        for (int top = 12; top >= 4; top--) {
            int need = 0x1f << (top - 4);
            if ((mask & need) == need) return top;
        }
        if ((mask & 0x100f) == 0x100f) return 3; // wheel A-2-3-4-5
        return -1;
    }

    public static int eval(int[] cards, int n) {
        int[] cnt = new int[13];
        int[] suitMask = new int[4];
        int[] suitCnt = new int[4];
        int all = 0;
        for (int i = 0; i < n; i++) {
            int r = cards[i] >> 2, s = cards[i] & 3;
            cnt[r]++; suitMask[s] |= 1 << r; suitCnt[s]++; all |= 1 << r;
        }
        for (int s = 0; s < 4; s++) if (suitCnt[s] >= 5) {
            int sf = straightTop(suitMask[s]);
            if (sf >= 0) return (8 << 20) | sf;
        }
        int quad = -1, trip1 = -1, trip2 = -1, pair1 = -1, pair2 = -1;
        for (int r = 12; r >= 0; r--) {
            if (cnt[r] == 4) quad = r;
            else if (cnt[r] == 3) { if (trip1 < 0) trip1 = r; else if (trip2 < 0) trip2 = r; }
            else if (cnt[r] == 2) { if (pair1 < 0) pair1 = r; else if (pair2 < 0) pair2 = r; }
        }
        if (quad >= 0) return (7 << 20) | (quad << 4) | topRanks(all & ~(1 << quad), 1);
        if (trip1 >= 0 && (trip2 >= 0 || pair1 >= 0)) {
            int p = Math.max(trip2, pair1);
            return (6 << 20) | (trip1 << 4) | p;
        }
        for (int s = 0; s < 4; s++) if (suitCnt[s] >= 5) return (5 << 20) | topRanks(suitMask[s], 5);
        int st = straightTop(all);
        if (st >= 0) return (4 << 20) | st;
        if (trip1 >= 0) return (3 << 20) | (trip1 << 8) | topRanks(all & ~(1 << trip1), 2);
        if (pair2 >= 0) return (2 << 20) | (pair1 << 8) | (pair2 << 4) | topRanks(all & ~(1 << pair1) & ~(1 << pair2), 1);
        if (pair1 >= 0) return (1 << 20) | (pair1 << 12) | topRanks(all & ~(1 << pair1), 3);
        return topRanks(all, 5);
    }

    /** Pack the k highest ranks of a mask, 4 bits each. */
    private static int topRanks(int mask, int k) {
        int out = 0, got = 0;
        for (int r = 12; r >= 0 && got < k; r--) if ((mask & (1 << r)) != 0) { out = (out << 4) | r; got++; }
        while (got++ < k) out <<= 4;
        return out;
    }
}
