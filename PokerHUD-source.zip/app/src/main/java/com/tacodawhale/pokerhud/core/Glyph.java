package com.tacodawhale.pokerhud.core;

/** A rank glyph cropped to its ink and resampled to a fixed grid. */
public final class Glyph {
    public static final int GW = 20, GH = 28;

    public final boolean[] bits;   // GW * GH
    public final float aspect;     // width / height of the original ink box

    public Glyph(boolean[] bits, float aspect) {
        this.bits = bits; this.aspect = aspect;
    }

    /** Similarity 0..1 (pixel agreement, penalised for a different shape). */
    public float similarity(Glyph o) {
        int same = 0;
        for (int i = 0; i < bits.length; i++) if (bits[i] == o.bits[i]) same++;
        float s = same / (float) bits.length;
        float ap = (float) Math.abs(Math.log(aspect / o.aspect));
        return s - 0.35f * ap;
    }

    public String encode() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format(java.util.Locale.US, "%.3f", aspect)).append(':');
        for (int i = 0; i < bits.length; i += 4) {
            int n = 0;
            for (int k = 0; k < 4; k++) n = (n << 1) | ((i + k < bits.length && bits[i + k]) ? 1 : 0);
            sb.append(Integer.toHexString(n));
        }
        return sb.toString();
    }

    public static Glyph decode(String s) {
        int c = s.indexOf(':');
        float a = Float.parseFloat(s.substring(0, c));
        String hex = s.substring(c + 1);
        boolean[] b = new boolean[GW * GH];
        for (int i = 0; i < b.length; i++) {
            int n = Character.digit(hex.charAt(i / 4), 16);
            b[i] = ((n >> (3 - (i % 4))) & 1) == 1;
        }
        return new Glyph(b, a);
    }

    /** Build a glyph from an ink mask (w x h) – crops to the ink and resamples. */
    public static Glyph fromMask(boolean[] mask, int w, int h) {
        int x0 = w, y0 = h, x1 = -1, y1 = -1;
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) if (mask[y * w + x]) {
            if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y;
        }
        if (x1 < 0) return null;
        int bw = x1 - x0 + 1, bh = y1 - y0 + 1;
        boolean[] out = new boolean[GW * GH];
        for (int gy = 0; gy < GH; gy++) for (int gx = 0; gx < GW; gx++) {
            int sx0 = x0 + gx * bw / GW, sx1 = Math.max(sx0 + 1, x0 + (gx + 1) * bw / GW);
            int sy0 = y0 + gy * bh / GH, sy1 = Math.max(sy0 + 1, y0 + (gy + 1) * bh / GH);
            int on = 0, tot = 0;
            for (int y = sy0; y < sy1; y++) for (int x = sx0; x < sx1; x++) { tot++; if (mask[y * w + x]) on++; }
            out[gy * GW + gx] = on * 100 >= tot * 35;
        }
        return new Glyph(out, bw / (float) bh);
    }
}
