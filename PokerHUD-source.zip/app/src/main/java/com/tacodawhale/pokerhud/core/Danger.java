package com.tacodawhale.pokerhud.core;

import java.util.ArrayList;
import java.util.List;

/**
 * Warnings for when the board makes hands possible that beat yours: flushes, straights, full houses.
 * Says nothing when you already hold that kind of hand (or better).
 */
public final class Danger {

    /** @return short warnings, most dangerous first (empty if the board is safe for you). */
    public static List<String> warnings(int[] hero, int[] board) {
        List<String> out = new ArrayList<>();
        int n = board.length;
        if (n < 3) return out;
        int[] all = new int[n + 2];
        System.arraycopy(board, 0, all, 0, n);
        all[n] = hero[0]; all[n + 1] = hero[1];
        int mine = HandEval.category(HandEval.eval(all, n + 2));   // 4 straight, 5 flush, 6 full house ...

        // flush
        int maxSuit = 0;
        for (int s = 0; s < 4; s++) {
            int c = 0;
            for (int b : board) if ((b & 3) == s) c++;
            maxSuit = Math.max(maxSuit, c);
        }
        if (mine < 5) {
            if (maxSuit >= 4) out.add("4 to a flush – one card makes a flush");
            else if (maxSuit == 3) out.add("Flush possible");
        }

        // straight: most board ranks inside any 5-rank window (ace counts high and low)
        int mask = 0;
        for (int b : board) { int r = b >> 2; mask |= 1 << (r + 1); if (r == 12) mask |= 1; }
        int most = 0;
        for (int lo = 0; lo + 4 <= 13; lo++) most = Math.max(most, Integer.bitCount(mask & (0x1F << lo)));
        if (mine < 4) {
            if (most >= 4) out.add("4 to a straight – one card makes a straight");
            else if (most == 3) out.add("Straight possible");
        }

        // paired board -> full house / quads
        int[] cnt = new int[13];
        boolean paired = false;
        for (int b : board) if (++cnt[b >> 2] >= 2) paired = true;
        if (paired && mine < 6) out.add("Board paired – full house possible");

        // you have a straight / flush, but a bigger one of the same kind is possible
        if (mine == 4 || mine == 5) {
            int myScore = HandEval.eval(all, n + 2);
            if (beatenBySameKind(myScore, mine, hero, board))
                out.add(mine == 5 ? "Higher flush possible" : "Higher straight possible");
        }
        return out;
    }

    /** True if no two unseen cards would give anyone a better hand than yours right now ("the nuts"). */
    public static boolean isNuts(int[] hero, int[] board) {
        int n = board.length;
        if (n < 3) return false;
        int[] all = new int[n + 2];
        System.arraycopy(board, 0, all, 0, n);
        all[n] = hero[0]; all[n + 1] = hero[1];
        int mine = HandEval.eval(all, n + 2);
        boolean[] seen = new boolean[52];
        for (int c : all) seen[c] = true;
        int[] theirs = new int[n + 2];
        System.arraycopy(board, 0, theirs, 0, n);
        for (int a = 0; a < 52; a++) {
            if (seen[a]) continue;
            for (int b = a + 1; b < 52; b++) {
                if (seen[b]) continue;
                theirs[n] = a; theirs[n + 1] = b;
                if (HandEval.eval(theirs, n + 2) > mine) return false;
            }
        }
        return true;
    }

    private static boolean beatenBySameKind(int myScore, int myCat, int[] hero, int[] board) {
        int n = board.length;
        boolean[] seen = new boolean[52];
        for (int c : board) seen[c] = true;
        seen[hero[0]] = true; seen[hero[1]] = true;
        int[] theirs = new int[n + 2];
        System.arraycopy(board, 0, theirs, 0, n);
        for (int a = 0; a < 52; a++) {
            if (seen[a]) continue;
            for (int b = a + 1; b < 52; b++) {
                if (seen[b]) continue;
                theirs[n] = a; theirs[n + 1] = b;
                int sc = HandEval.eval(theirs, n + 2);
                if (sc > myScore && HandEval.category(sc) == myCat) return true;
            }
        }
        return false;
    }
}
