package com.tacodawhale.pokerhud.core;

/**
 * Bluff spots: moments when betting with a weak hand is likely to win the pot – and moments when it won't.
 */
public final class Spots {

    /**
     * @param st         the table right now
     * @param position   your position (0 button … 5 cutoff, -1 unknown)
     * @param seatTypes  each opponent seat's player type ("Rock", "Calling station" …) or null if unknown
     * @param weak       your hand is in the fold / check zone (otherwise just bet it for value)
     * @param chartGroup your starting-hand chart group (P S G O F), used for steals before the flop
     * @return "" when there's nothing to say
     */
    public static String bluff(TableReader.State st, int position, String[] seatTypes, boolean weak, char chartGroup) {
        if (!st.heroTurn) return "";
        int inHand = 0, checked = 0, calledOrRaised = 0, rocks = 0, stations = 0;
        for (int i = 0; i < st.seats.length; i++) {
            if (st.seats[i] == TableReader.SeatStatus.EMPTY_OR_OUT) continue;
            inHand++;
            char a = st.actions[i];
            if (a == 'K') checked++;
            if (a == 'C' || a == 'R') calledOrRaised++;
            String t = seatTypes == null ? null : seatTypes[i];
            if ("Rock".equals(t)) rocks++;
            if ("Calling station".equals(t)) stations++;
        }
        if (inHand == 0) return "";
        if (stations > 0 && weak) return "No bluff: calling station in";

        boolean late = position == 0 || position == 5;
        if (st.board.isEmpty()) {
            // steal: nobody has called or raised yet and you're in a late seat
            if (late && calledOrRaised == 0 && chartGroup != 'F') return "Steal spot: raise for the blinds";
            return "";
        }
        if (!weak) return "";
        if (checked == inHand && inHand <= 2) return "Bluff spot: all checked – bet";
        if (rocks == inHand && calledOrRaised == 0) return "Bluff spot: only Rocks left";
        return "";
    }

    /** What to do against one opponent: {tag text, kind}. Kinds: call, fold, value, bluff, nobluff, check. */
    public static String[] vsPlayer(double eq, char action, String type, int boardCards) {
        double need = Advisor.thresholds(1, boardCards)[0];
        String t = type == null ? "" : type;
        switch (t) {                                   // how much their raises really mean
            case "Maniac": need *= 0.80; break;
            case "Loose": need *= 0.90; break;
            case "Rock": need *= 1.20; break;
            case "Solid": need *= 1.10; break;
            case "Calling station": need *= 1.10; break;
            default: break;
        }
        boolean station = t.equals("Calling station");
        if (action == 'R') {
            if (eq >= need) {
                String why = t.equals("Maniac") ? "they raise with weak hands"
                        : t.equals("Loose") ? "they raise light" : "you're ahead of their raises";
                return new String[]{"\u2713 Call \u2013 " + why, "call"};
            }
            String why = t.equals("Rock") ? "Rocks raise strong" : t.equals("Solid") ? "they raise strong hands"
                    : station ? "a station raising is strong" : "you're behind";
            return new String[]{"\u2717 Fold to them \u2013 " + why, "fold"};
        }
        if (eq >= 0.60) return new String[]{"\u2191 Bet for value" + (station ? " \u2013 they'll call" : ""), "value"};
        if (action == 'C') return new String[]{"Check \u2013 they called, careful", "check"};
        if (station) return new String[]{"\u270B Check \u2013 don't bluff them", "nobluff"};
        if (t.equals("Rock") || t.equals("Average") || t.equals("Solid"))
            return new String[]{"\uD83C\uDFAD Bluff OK if you miss later", "bluff"};
        return new String[]{"Check", "check"};
    }
}
