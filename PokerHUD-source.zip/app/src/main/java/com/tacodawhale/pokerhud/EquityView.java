package com.tacodawhale.pokerhud;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.TypedValue;
import android.view.View;

/**
 * The equity box opened with the % button: a win / tie / lose bar, your chance against each opponent on their own,
 * which hands beat you most, and how many next cards help you. Filled in live from the table.
 */
final class EquityView extends View {
    String hand = "";
    double win, tie, lose;
    String[] oppNames = new String[0], oppActions = new String[0];
    double[] oppEquity = new double[0];
    String[] oppTypes = new String[0], oppAdvice = new String[0], oppKind = new String[0];
    String[] oppRaises = new String[0];   // e.g. "raised 2× now · 14 total"
    String[] oppShown = new String[0];
    String[] oppBets = new String[0];     // e.g. "folds to bets 72% · re-raises 4%"    // e.g. "showed 9♠3♦ on a raise"
    String[] loseTo = new String[0];
    String nextCard = "";          // "" = not shown (before the flop / on the river)
    boolean empty = true;          // no hand to show yet

    private final float dp;
    private final Paint title = paint(15, 0xFFFFFFFF, true), small = paint(11, 0xFFC8C8C8, false);
    private final Paint label = paint(11, 0xFFAAAAAA, true), val = paint(13, 0xFFFFFFFF, true);
    private final Paint name = paint(12, 0xFFFFFFFF, true), fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tag = paint(11, 0xFFFFFFFF, true);

    EquityView(Context c) {
        super(c);
        dp = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 1, c.getResources().getDisplayMetrics());
        for (Paint p : new Paint[]{title, small, label, val, name, tag}) p.setTextSize(p.getTextSize() * dp);
    }

    private static Paint paint(float size, int color, boolean bold) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setTextSize(size);
        p.setColor(color);
        if (bold) p.setTypeface(Typeface.DEFAULT_BOLD);
        return p;
    }

    private float rows() {
        if (empty) return 60;
        int extra = 0;
        for (String r : oppRaises) if (r != null && !r.isEmpty()) extra += 15;
        for (String r : oppShown) if (r != null) extra += 15;
        for (String r : oppBets) if (r != null) extra += 15;
        return 132 + 46 * oppNames.length + extra + (loseTo.length > 0 ? 46 : 0) + (nextCard.isEmpty() ? 0 : 24);
    }

    @Override
    protected void onMeasure(int w, int h) {
        setMeasuredDimension((int) (360 * dp), (int) (rows() * dp));
    }

    void refresh() { requestLayout(); invalidate(); }

    @Override
    protected void onDraw(Canvas c) {
        float x = 12 * dp, w = getWidth() - 24 * dp, y = 24 * dp;
        c.drawText("% Equity", x, y, title);
        if (!hand.isEmpty()) c.drawText(hand, getWidth() - 12 * dp - small.measureText(hand), y, small);
        if (empty) {
            c.drawText("Shows up when you have cards", x, y + 24 * dp, small);
            return;
        }
        // win / tie / lose bar
        y += 12 * dp;
        float bh = 14 * dp;
        fill.setColor(0xFFAA322D);
        c.drawRoundRect(new RectF(x, y, x + w, y + bh), bh / 2, bh / 2, fill);
        fill.setColor(0xFFC8C8C8);
        c.drawRect(x + (float) (w * win), y, x + (float) (w * (win + tie)), y + bh, fill);
        fill.setColor(0xFF3CD25A);
        c.drawRoundRect(new RectF(x, y, x + (float) Math.max(bh, w * win), y + bh), bh / 2, bh / 2, fill);
        y += bh + 18 * dp;
        val.setColor(0xFF4CFF6A);
        c.drawText("Win " + pct(win), x, y, val);
        val.setColor(0xFFD2D2D2);
        c.drawText("Tie " + pct(tie), x + w * 0.38f, y, val);
        val.setColor(0xFFFF6E64);
        c.drawText("Lose " + pct(lose), x + w * 0.68f, y, val);

        // against each opponent: name, type · what they did, your chance vs them, and what to do
        y += 26 * dp;
        c.drawText("Against each player \u2013 what to do", x, y, label);
        for (int i = 0; i < oppNames.length; i++) {
            y += 20 * dp;
            c.drawText(oppNames[i], x, y, name);
            String sub = (i < oppTypes.length && oppTypes[i] != null ? oppTypes[i] : "")
                    + (oppActions[i].isEmpty() ? "" : (i < oppTypes.length && oppTypes[i] != null ? " \u00B7 " : "") + oppActions[i]);
            sub = sub.replace("Calling station", "Station");   // keep it clear of the bar
            if (!sub.isEmpty()) c.drawText(sub, x + 88 * dp, y, small);
            float bx = x + 236 * dp, bw = 76 * dp, top = y - 10 * dp;
            double e = oppEquity[i];
            int col = e >= 0.6 ? 0xFF4CFF6A : e >= 0.4 ? 0xFFFFC23D : 0xFFFF5A4A;
            fill.setColor(0xFF3C3C3C);
            c.drawRoundRect(new RectF(bx, top, bx + bw, top + 10 * dp), 5 * dp, 5 * dp, fill);
            fill.setColor(col);
            c.drawRoundRect(new RectF(bx, top, bx + (float) Math.max(10 * dp, bw * e), top + 10 * dp), 5 * dp, 5 * dp, fill);
            val.setColor(col);
            c.drawText(pct(e), bx + bw + 6 * dp, y, val);
            // what to do vs them
            if (i < oppAdvice.length && oppAdvice[i] != null) {
                String k = i < oppKind.length ? oppKind[i] : "check";
                int bg, fg;
                switch (k) {
                    case "call": case "value": bg = 0xFF0E3C1C; fg = 0xFF78FF96; break;
                    case "fold": bg = 0xFF461212; fg = 0xFFFF8278; break;
                    case "bluff": case "nobluff": bg = 0xFF4A0F45; fg = 0xFFFF8CF2; break;
                    default: bg = 0xFF333333; fg = 0xFFDDDDDD;
                }
                float ty = y + 6 * dp, tw = tag.measureText(oppAdvice[i]) + 16 * dp;
                fill.setColor(bg);
                c.drawRoundRect(new RectF(x, ty, x + tw, ty + 19 * dp), 9.5f * dp, 9.5f * dp, fill);
                tag.setColor(fg);
                c.drawText(oppAdvice[i], x + 8 * dp, ty + 14 * dp, tag);
            }
            y += 26 * dp;
            // raise count on its own orange line under the tip
            if (i < oppRaises.length && oppRaises[i] != null && !oppRaises[i].isEmpty()) {
                int old = small.getColor();
                small.setColor(0xFFFFB45A);
                c.drawText(oppRaises[i], x + 4 * dp, y + 10 * dp, small);
                small.setColor(old);
                y += 15 * dp;
            }
            if (i < oppShown.length && oppShown[i] != null) {
                int old = small.getColor();
                small.setColor(0xFF7FD8FF);
                c.drawText(oppShown[i], x + 4 * dp, y + 10 * dp, small);
                small.setColor(old);
                y += 15 * dp;
            }
            if (i < oppBets.length && oppBets[i] != null) {
                int old = small.getColor();
                small.setColor(0xFF96EB96);         // green: folds to bets / re-raises
                c.drawText(oppBets[i], x + 4 * dp, y + 10 * dp, small);
                small.setColor(old);
                y += 15 * dp;
            }
        }

        // what beats you
        if (loseTo.length > 0) {
            y += 26 * dp;
            c.drawText("You lose most to", x, y, label);
            y += 8 * dp;
            float cx = x;
            for (String s : loseTo) {
                float tw = small.measureText(s) + 14 * dp;
                fill.setColor(0xFF5A1E1E);
                c.drawRoundRect(new RectF(cx, y, cx + tw, y + 18 * dp), 9 * dp, 9 * dp, fill);
                int old = small.getColor();
                small.setColor(0xFFFFAAA0);
                c.drawText(s, cx + 7 * dp, y + 13 * dp, small);
                small.setColor(old);
                cx += tw + 6 * dp;
            }
            y += 18 * dp;
        }

        // next card
        if (!nextCard.isEmpty()) {
            y += 22 * dp;
            c.drawText("Next card helps you:", x, y, label);
            int old = small.getColor();
            small.setColor(0xFF3DEBFF);
            c.drawText(nextCard, x + 140 * dp, y, small);
            small.setColor(old);
        }
    }

    private static String pct(double v) { return Math.round(v * 100) + "%"; }
}
