package com.tacodawhale.pokerhud.core;

/**
 * Finds where the game sits inside the captured screen – full screen, or shrunk inside a
 * browser / screen-mirroring window (e.g. AirDroid) with black bars beside it.
 * The game keeps the 1080 x 2340 shape of the phone it runs on.
 */
public final class Viewport {
    public final int x, y, w, h;

    public Viewport(int x, int y, int w, int h) { this.x = x; this.y = y; this.w = w; this.h = h; }

    public static Viewport full(Frame f) { return new Viewport(0, 0, f.w, f.h); }

    /** Map a reference box (1080 x 2340 coordinates) into the frame. */
    public int[] map(int[] box) {
        double s = w / (double) Layout.REF_W, t = h / (double) Layout.REF_H;
        return new int[]{x + (int) Math.round(box[0] * s), y + (int) Math.round(box[1] * t),
                x + (int) Math.round(box[2] * s), y + (int) Math.round(box[3] * t)};
    }

    @Override public String toString() { return x + "," + y + " " + w + "x" + h; }

    /** Fraction of a column (rows y0..y1, skipping the excluded rows) that is pure black. */
    private static float blackFraction(Frame f, int x, int y0, int y1, int[] ex) {
        int dark = 0, n = 0;
        for (int y = y0; y < y1; y += 2) {
            if (ex != null && y >= ex[1] && y < ex[3] && x >= ex[0] && x < ex[2]) continue;
            n++;
            if (Frame.v(f.get(x, y)) <= 6) dark++;
        }
        return n == 0 ? 1f : dark / (float) n;
    }

    /** Mean brightness of a row (NaN if the whole row is hidden under the excluded area). */
    private static float rowMean(Frame f, int y, int x0, int x1, int[] ex) {
        long s = 0; int n = 0;
        for (int x = x0; x < x1; x += 2) {
            if (ex != null && y >= ex[1] && y < ex[3] && x >= ex[0] && x < ex[2]) continue;
            s += Frame.v(f.get(x, y)); n++;
        }
        return n < 8 ? Float.NaN : s / (float) n;
    }

    private static float edge(float[] rm, int y) {
        float a = rm[y - 2], b = rm[y + 1];
        return Float.isNaN(a) || Float.isNaN(b) ? 0f : Math.abs(a - b);
    }

    public static Viewport detect(Frame f) { return detect(f, null); }

    public static Viewport detect(Frame f, int[] exclude) { return candidates(f, exclude).get(0); }

    /**
     * Possible game areas, most likely first. The caller reads the table in each and keeps the one that reads
     * best – the HUD panel or anything else on screen can hide an edge, but it can't fake a table.
     * @param exclude screen rectangle {x0,y0,x1,y1} to ignore (the HUD panel itself), or null.
     */
    public static java.util.List<Viewport> candidates(Frame f, int[] exclude) {
        java.util.List<Viewport> out = new java.util.ArrayList<>();
        // 1. pure-black bars at the left / right. The game's own dark edge is near-black, not pure black.
        int y0 = f.h / 5, y1 = f.h * 4 / 5;
        boolean[] bar = new boolean[f.w];
        for (int x = 0; x < f.w; x++) bar[x] = blackFraction(f, x, y0, y1, exclude) >= 0.80f;
        int left = 0, right = f.w - 1;
        int s = -1;
        for (int x = 0; x < Math.min(12, f.w); x++) if (bar[x]) { s = x; break; }   // tolerate a few odd edge columns
        if (s >= 0) { left = s; while (left < f.w / 2 && bar[left]) left++; }
        s = -1;
        for (int x = f.w - 1; x >= Math.max(0, f.w - 12); x--) if (bar[x]) { s = x; break; }
        if (s >= 0) { right = s; while (right > f.w / 2 && bar[right]) right--; }
        // Mirroring apps centre the stream. Anything drawn over a bar can only make that bar look narrower,
        // so when both sides have bars, trust the wider one.
        if (left > 0 && right < f.w - 1) {
            int margin = Math.max(left, f.w - 1 - right);
            left = margin; right = f.w - 1 - margin;
        }
        int w = right - left + 1;
        if (w < f.w / 4) { out.add(full(f)); return out; }
        int h = Math.round(w * Layout.REF_H / (float) Layout.REF_W);

        if (h >= f.h - 4) {
            h = Math.min(h, f.h);
            int ww = Math.round(h * Layout.REF_W / (float) Layout.REF_H);
            out.add(new Viewport(Math.max(0, left + (w - ww) / 2), 0, Math.min(ww, f.w), h));
            out.add(full(f));
            return out;
        }

        // 2. vertical position: score every top position by the sharpness of the game's top and bottom edges
        int x0 = left + w / 10, x1 = right - w / 10;
        float[] rm = new float[f.h];
        for (int y = 0; y < f.h; y++) rm[y] = rowMean(f, y, x0, x1, exclude);
        int maxTop = f.h - h - 3;
        float[] score = new float[Math.max(0, maxTop + 1)];
        for (int top = 2; top <= maxTop; top++) score[top] = edge(rm, top) + edge(rm, top + h);
        // best few, at least 12 px apart
        for (int k = 0; k < 4; k++) {
            int best = -1;
            for (int top = 2; top <= maxTop; top++) {
                if (best >= 0 && score[top] <= score[best]) continue;
                boolean near = false;
                for (Viewport v : out) if (Math.abs(v.y - top) < 12) { near = true; break; }
                if (!near) best = top;
            }
            if (best < 0 || score[best] < 4) break;
            out.add(new Viewport(left, best, w, h));
        }
        out.add(new Viewport(left, Math.max(0, (f.h - h) / 2), w, h));   // centred, as a fallback
        return out;
    }

    /**
     * Find the game by reading the table: try the edge-based guesses plus every height position in coarse steps,
     * then fine-tune around the best. Slow-ish (dozens of reads), so run it only when there's no good lock.
     * @return the best area and its quality, or null if nothing looked like a table.
     */
    public static Object[] search(Frame f, int[] exclude, TableReader reader) {
        java.util.List<Viewport> cands = candidates(f, exclude);
        Viewport base = cands.get(0);
        java.util.List<Viewport> tryList = new java.util.ArrayList<>(cands);
        int maxTop = Math.max(0, f.h - base.h);
        for (int top = 0; top <= maxTop; top += 6) tryList.add(new Viewport(base.x, top, base.w, base.h));
        Viewport best = null; float bq = -1e9f;
        for (Viewport v : tryList) {
            float q = reader.read(f, v).quality();
            if (q > bq) { bq = q; best = v; }
        }
        // fine-tune: score every position near the best, then take the middle of the range that reads (almost)
        // as well as the best one – the safest spot, a few pixels from where the reading starts to break.
        int c0 = best.y, lo = Math.max(0, c0 - 16), hi = Math.min(maxTop, c0 + 16);
        float[] qs = new float[hi - lo + 1];
        for (int top = lo; top <= hi; top++) {
            qs[top - lo] = reader.read(f, new Viewport(best.x, top, best.w, best.h)).quality();
            if (qs[top - lo] > bq) { bq = qs[top - lo]; c0 = top; }
        }
        int a = c0, z = c0;
        while (a - 1 >= lo && qs[a - 1 - lo] >= bq - 0.6f) a--;
        while (z + 1 <= hi && qs[z + 1 - lo] >= bq - 0.6f) z++;
        best = new Viewport(best.x, (a + z) / 2, best.w, best.h);
        return new Object[]{best, bq};
    }

    public boolean sameAs(Viewport o) {
        return o != null && Math.abs(x - o.x) <= 2 && Math.abs(y - o.y) <= 2 && Math.abs(w - o.w) <= 2;
    }
}
