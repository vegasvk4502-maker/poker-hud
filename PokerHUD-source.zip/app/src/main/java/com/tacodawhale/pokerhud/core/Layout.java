package com.tacodawhale.pokerhud.core;

/**
 * Where everything sits on the table, in reference pixels of a 1080 x 2340 portrait
 * screenshot (Galaxy S25 native resolution). Scaled to the real capture size at runtime.
 */
public final class Layout {
    public static final int REF_W = 1080, REF_H = 2340;

    // Board: five card slots.
    public static final int BOARD_X0 = 144, BOARD_STEP_X100 = 16125; // step = 161.25 px
    public static final int BOARD_Y = 914, CARD_W = 146, CARD_H = 194;

    // Hero (you) – two fanned cards above your name, bottom-left.
    public static final int[] HERO_AREA = {48, 1730, 330, 1890};
    // Tall enough for ranks printed a little higher on tilted cards; background above the card is ignored.
    public static final int[][] HERO_RANK = {{52, 1712, 145, 1821}, {150, 1700, 240, 1809}};
    public static final int[][] HERO_SUIT = {{52, 1818, 120, 1882}, {146, 1806, 212, 1868}};
    public static final int[] HERO_PLATE = {25, 1898, 352, 2038};
    /** On your turn: red countdown ring with a white number, right of your cards. */
    public static final int[] HERO_TIMER = {300, 1590, 396, 1684};
    /** On your turn: grey raise-size buttons (All-in / 4X / 3X / 2.5X) on the right. */
    public static final int[] RAISE_PANEL = {740, 1650, 870, 2020};

    /** Opponent seats, clockwise from your left. Name-plate top-left corner (plate is 228 x 85). */
    public static final String[] SEAT_NAMES = {"Left", "Top-left", "Top", "Top-right", "Right"};
    public static final int[][] SEAT_PLATE = {
            {44, 1325},   // left-middle
            {72, 698},    // upper-left
            {426, 540},   // top
            {780, 698},   // upper-right
            {808, 1325},  // right-middle
    };
    public static final int PLATE_W = 228, PLATE_H = 85;

    /** Card-back box for a seat, relative to its plate: x+50..x+180, y-58..y-4. */
    public static int[] seatCards(int seat) {
        int[] p = SEAT_PLATE[seat];
        return new int[]{p[0] + 50, p[1] - 58, p[0] + 180, p[1] - 4};
    }

    /** Top strip of the name plate (name text row) – turns red while that player is deciding. */
    public static int[] seatPlateTop(int seat) {
        int[] p = SEAT_PLATE[seat];
        return new int[]{p[0] + 10, p[1] + 4, p[0] + PLATE_W - 10, p[1] + 36};
    }

    /** Countdown bar under the name plate – shown while that player is deciding. */
    public static int[] seatTimer(int seat) {
        int[] p = SEAT_PLATE[seat];
        return new int[]{p[0] + 20, p[1] + 98, p[0] + 180, p[1] + 122};
    }

    /** Coloured last-action label under the name plate (RAISE orange, CHECK green, FOLD blue). */
    public static int[] seatLabel(int seat) {
        int[] p = SEAT_PLATE[seat];
        return new int[]{p[0] + 20, p[1] + 90, p[0] + 208, p[1] + 116};
    }

    /**
     * Where the gold dealer button sits for each seat, in play order (clockwise): you, Left, Top-left, Top,
     * Top-right, Right. Measured from real screenshots.
     */
    public static final int[][] DEALER_SPOT = {
            {458, 1671},   // you
            {315, 1345},   // Left
            {344, 732},    // Top-left
            {701, 639},    // Top
            {733, 809},    // Top-right
            {764, 1415},   // Right
    };

    public static int[] boardCard(int i) {
        int x = BOARD_X0 + (BOARD_STEP_X100 * i) / 100;
        return new int[]{x, BOARD_Y, x + CARD_W, BOARD_Y + CARD_H};
    }

    /** Rank glyph box inside a board card. */
    public static int[] boardRank(int i) {
        int[] c = boardCard(i);
        return new int[]{c[0] + (int) (CARD_W * 0.04), c[1] + (int) (CARD_H * 0.05),
                c[0] + (int) (CARD_W * 0.56), c[1] + (int) (CARD_H * 0.40)};
    }

    /** Small suit pip box inside a board card. */
    public static int[] boardSuit(int i) {
        int[] c = boardCard(i);
        return new int[]{c[0] + (int) (CARD_W * 0.04), c[1] + (int) (CARD_H * 0.40),
                c[0] + (int) (CARD_W * 0.38), c[1] + (int) (CARD_H * 0.63)};
    }

    /** Scale a reference box to a frame of size w x h. */
    public static int[] scale(int[] box, int w, int h) {
        double sx = w / (double) REF_W, sy = h / (double) REF_H;
        return new int[]{(int) Math.round(box[0] * sx), (int) Math.round(box[1] * sy),
                (int) Math.round(box[2] * sx), (int) Math.round(box[3] * sy)};
    }
}
