package com.tacodawhale.pokerhud.core;

import java.util.ArrayList;
import java.util.List;

/** Reads your cards, the board and every seat's status from one frame. */
public final class TableReader {

    public static final class Card {
        public final char rank, suit;        // suit: s h d c
        public final boolean sure;
        public final float score;            // how well the rank matched (0..1)
        public final Glyph glyph;            // kept so unknown ranks can be taught
        Card(char r, char s, boolean sure, float score, Glyph g) {
            rank = r; suit = s; this.sure = sure; this.score = score; glyph = g;
        }
        public String text() { return "" + rank + suit; }
        public String pretty() {
            String r = rank == 'T' ? "10" : String.valueOf(rank);
            switch (suit) {
                case 's': return r + "♠";
                case 'h': return r + "♥";
                case 'd': return r + "♦";
                default:  return r + "♣";
            }
        }
    }

    public enum SeatStatus { EMPTY_OR_OUT, IN_HAND, DECIDING }

    public static final class State {
        public final List<Card> hero = new ArrayList<>();
        public final List<Card> board = new ArrayList<>();
        public final SeatStatus[] seats = new SeatStatus[Layout.SEAT_PLATE.length];
        /** Last action shown under each seat: 'R' raise, 'C' call, 'K' check, 'F' fold, '-' none / unknown. */
        public final char[] actions = new char[Layout.SEAT_PLATE.length];
        public boolean heroTurn;
        /** Seat with the dealer button, in play order: 0 = you, 1 = Left ... 5 = Right; -1 if not seen. */
        public int dealer = -1;
        /** Cards a player is showing face up (showdown), per seat; null if none shown. */
        public final Card[][] shown = new Card[Layout.SEAT_PLATE.length][];

        /** Your position: 0 = button, 1 = small blind, 2 = big blind, 3 = first to act, 4 = middle, 5 = cutoff. */
        public int heroPosition() { return dealer < 0 ? -1 : (0 - dealer + 6) % 6; }
        public int opponentsInHand() {
            int n = 0;
            for (SeatStatus s : seats) if (s != SeatStatus.EMPTY_OR_OUT) n++;
            return n;
        }
        public int decidingSeat() {
            for (int i = 0; i < seats.length; i++) if (seats[i] == SeatStatus.DECIDING) return i;
            return -1;
        }
        /**
         * How convincingly this looks like the poker table (used to pick the right game area on screen):
         * well-matched cards, players holding cards, action labels.
         */
        public float quality() {
            float q = 0;
            for (Card c : hero) q += c.score >= 0.6f ? 4 * c.score : -2;
            for (Card c : board) q += c.score >= 0.6f ? 2 * c.score : -1;
            for (int i = 0; i < seats.length; i++) {
                if (seats[i] != SeatStatus.EMPTY_OR_OUT) q += 1;
                if (actions[i] != '-') q += 1;
            }
            return q;
        }

        public boolean allSure() {
            for (Card c : hero) if (!c.sure) return false;
            for (Card c : board) if (!c.sure) return false;
            return true;
        }
    }

    private final Templates templates;

    public TableReader(Templates t) { templates = t; }

    public State read(Frame f) { return read(f, Viewport.detect(f)); }

    public State read(Frame f, Viewport vp) {
        State st = new State();

        // Your cards
        int[] ha = vp.map(Layout.HERO_AREA);
        if (faceFraction(f, ha) > 0.45f) {
            for (int i = 0; i < 2; i++) {
                Card c = readCard(f, vp.map(Layout.HERO_RANK[i]),
                        vp.map(Layout.HERO_SUIT[i]), true);
                if (c != null) st.hero.add(c);
            }
            if (st.hero.size() != 2) st.hero.clear();
        }

        // Board
        for (int i = 0; i < 5; i++) {
            int[] cb = vp.map(Layout.boardCard(i));
            int[] inner = {cb[0] + (cb[2] - cb[0]) / 6, cb[1] + (cb[3] - cb[1]) / 6,
                    cb[2] - (cb[2] - cb[0]) / 6, cb[3] - (cb[3] - cb[1]) / 6};
            if (faceFraction(f, inner) < 0.55f) break;
            Card c = readCard(f, vp.map(Layout.boardRank(i)),
                    vp.map(Layout.boardSuit(i)));
            if (c == null) break;
            st.board.add(c);
        }

        // Opponents
        for (int s = 0; s < st.seats.length; s++) {
            boolean cards = redFraction(f, vp.map(Layout.seatCards(s)), 150) > 0.12f;
            boolean deciding = redFraction(f, vp.map(Layout.seatPlateTop(s)), 90) > 0.45f
                    || redFraction(f, vp.map(Layout.seatTimer(s)), 150) > 0.10f;
            st.seats[s] = deciding ? SeatStatus.DECIDING : cards ? SeatStatus.IN_HAND : SeatStatus.EMPTY_OR_OUT;
            st.actions[s] = deciding ? '-' : actionLabel(f, vp.map(Layout.seatLabel(s)), vp.w);
        }
        st.heroTurn = yourTurn(f, vp);
        st.dealer = dealerSeat(f, vp);
        for (int i = 0; i < st.shown.length; i++) st.shown[i] = shownCards(f, vp, i);
        return st;
    }

    /**
     * Read the coloured action label: orange RAISE, green CHECK / CALL, blue FOLD. CHECK and CALL share the green,
     * so they're told apart by the width of the white word (CHECK is about 0.065 of the game's width, CALL 0.050).
     */
    static char actionLabel(Frame f, int[] b, int gameW) {
        int n = 0, orange = 0, green = 0, blue = 0, minx = Integer.MAX_VALUE, maxx = -1;
        for (int y = b[1]; y < b[3]; y++) for (int x = b[0]; x < b[2]; x++) {
            int c = f.get(x, y);
            if (Frame.v(c) > 200 && Frame.s(c) < 0.25f) { minx = Math.min(minx, x); maxx = Math.max(maxx, x); }
            if ((y - b[1]) % 2 != 0 || (x - b[0]) % 2 != 0) continue;
            n++;
            if (Frame.s(c) <= 0.45f || Frame.v(c) <= 127) continue;
            float hue = Frame.hue(c);
            if (hue >= 18 && hue <= 45) orange++;          // RAISE
            else if (hue >= 70 && hue <= 150) green++;     // CHECK / CALL
            else if (hue >= 190 && hue <= 245) blue++;     // FOLD
        }
        if (n == 0) return '-';
        int best = Math.max(orange, Math.max(green, blue));
        if (best < n * 0.40f) return '-';
        if (best == orange) return 'R';
        if (best == blue) return 'F';
        double textW = maxx < 0 ? 0 : (maxx - minx) / (double) gameW;
        return textW > 0 && textW < 0.058 ? 'C' : 'K';
    }

    /** Which seat has the gold dealer button ("D"), or -1. */
    static int dealerSeat(Frame f, Viewport vp) {
        int best = -1; float bestFrac = 0.15f;
        for (int i = 0; i < Layout.DEALER_SPOT.length; i++) {
            int[] c = Layout.DEALER_SPOT[i];
            int[] b = vp.map(new int[]{c[0] - 30, c[1] - 30, c[0] + 30, c[1] + 30});
            int gold = 0, n = 0;
            for (int y = b[1]; y < b[3]; y++) for (int x = b[0]; x < b[2]; x++) {
                int px = f.get(x, y); n++;
                float h = Frame.hue(px);
                if (h >= 38 && h <= 58 && Frame.s(px) > 0.5f && Frame.v(px) > 170) gold++;
            }
            float frac = n == 0 ? 0 : gold / (float) n;
            if (frac > bestFrac) { bestFrac = frac; best = i; }
        }
        return best;
    }

    /** Your turn: the countdown ring (red arc + white number) or the grey raise-size panel is showing. */
    static boolean yourTurn(Frame f, Viewport vp) {
        int[] b = vp.map(Layout.HERO_TIMER);
        int red = 0, white = 0, n = 0;
        for (int y = b[1]; y < b[3]; y++) for (int x = b[0]; x < b[2]; x++) {
            int c = f.get(x, y); n++;
            if (Frame.isRed(c, 150)) red++;
            else if (Frame.v(c) > 200 && Frame.s(c) < 0.2f) white++;
        }
        boolean ring = n > 0 && red > n * 0.03f && white > n * 0.015f;
        int[] p = vp.map(Layout.RAISE_PANEL);
        int grey = 0, m = 0;
        for (int y = p[1]; y < p[3]; y += 2) for (int x = p[0]; x < p[2]; x += 2) {
            int c = f.get(x, y); m++;
            int v = Frame.v(c);
            if (v >= 55 && v <= 130 && Frame.s(c) < 0.10f) grey++;
        }
        boolean panel = m > 0 && grey > m * 0.55f;
        return ring || panel;
    }

    /** Fraction of pixels that look like a card face (light, unsaturated). Works for dimmed cards too. */
    static float faceFraction(Frame f, int[] b) {
        int on = 0, tot = 0;
        for (int y = b[1]; y < b[3]; y += 2) for (int x = b[0]; x < b[2]; x += 2) {
            int c = f.get(x, y); tot++;
            if (Frame.v(c) > 95 && Frame.s(c) < 0.25f) on++;
        }
        return tot == 0 ? 0 : on / (float) tot;
    }

    static float redFraction(Frame f, int[] b, int minV) {
        int on = 0, tot = 0;
        for (int y = b[1]; y < b[3]; y += 2) for (int x = b[0]; x < b[2]; x += 2) {
            tot++;
            if (Frame.isRed(f.get(x, y), minV)) on++;
        }
        return tot == 0 ? 0 : on / (float) tot;
    }

    /** Ink mask of a box (anything clearly darker than the card face, or coloured), largest blobs only. */
    static boolean[] inkMask(Frame f, int[] b) {
        int w = b[2] - b[0], h = b[3] - b[1];
        if (w <= 2 || h <= 2) return null;
        int faceV = faceV(f, b);
        if (faceV < 95) return null;
        boolean[] m = new boolean[w * h];
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            int c = f.get(b[0] + x, b[1] + y);
            m[y * w + x] = Frame.colored(c) || Frame.v(c) < faceV * 0.55f;
        }
        return keepBigBlobs(m, w, h);
    }

    /** Card-face brightness = 75th percentile of the unsaturated pixels (0 if the box is mostly not card). */
    static int faceV(Frame f, int[] b) {
        int w = b[2] - b[0], h = b[3] - b[1];
        int[] hist = new int[256]; int n = 0;
        for (int y = b[1]; y < b[3]; y++) for (int x = b[0]; x < b[2]; x++) {
            int c = f.get(x, y);
            if (Frame.s(c) < 0.25f) { hist[Frame.v(c)]++; n++; }
        }
        if (n < w * h / 4) return 0;
        int acc = 0;
        for (int i = 0; i < 256; i++) { acc += hist[i]; if (acc >= n * 0.75) return i; }
        return 255;
    }

    /** Remove ink blobs that touch the top edge of the box (dark table background above a card). */
    static boolean[] dropTopTouching(boolean[] m, int w, int h) {
        if (m == null) return null;
        boolean[] out = m.clone();
        int[] stack = new int[w * h];
        boolean[] seen = new boolean[w * h];
        for (int x = 0; x < w; x++) {
            if (!out[x] || seen[x]) continue;
            int sp = 0; stack[sp++] = x; seen[x] = true;
            while (sp > 0) {
                int p = stack[--sp]; out[p] = false;
                int px = p % w, py = p / w;
                int[] nb = {px > 0 ? p - 1 : -1, px < w - 1 ? p + 1 : -1, py > 0 ? p - w : -1, py < h - 1 ? p + w : -1};
                for (int q : nb) if (q >= 0 && out[q] && !seen[q]) { seen[q] = true; stack[sp++] = q; }
            }
        }
        boolean any = false;
        for (boolean b : out) if (b) { any = true; break; }
        return any ? out : null;
    }

    static boolean[] keepBigBlobs(boolean[] m, int w, int h) {
        int[] lab = new int[w * h];
        List<Integer> sizes = new ArrayList<>(); sizes.add(0);
        int[] stack = new int[w * h];
        int next = 1;
        for (int i = 0; i < m.length; i++) {
            if (!m[i] || lab[i] != 0) continue;
            int sp = 0, size = 0; stack[sp++] = i; lab[i] = next;
            while (sp > 0) {
                int p = stack[--sp]; size++;
                int x = p % w, y = p / w;
                int[] nb = {x > 0 ? p - 1 : -1, x < w - 1 ? p + 1 : -1, y > 0 ? p - w : -1, y < h - 1 ? p + w : -1};
                for (int q : nb) if (q >= 0 && m[q] && lab[q] == 0) { lab[q] = next; stack[sp++] = q; }
            }
            sizes.add(size); next++;
        }
        int max = 0;
        for (int s : sizes) max = Math.max(max, s);
        if (max < 25) return null;
        boolean[] out = new boolean[w * h];
        for (int i = 0; i < m.length; i++) {
            int l = lab[i];
            // keep blobs at least 15% of the biggest (drops anti-aliasing specks and edge noise)
            if (l != 0 && sizes.get(l) >= max * 0.15f) out[i] = true;
        }
        return out;
    }

    /** Keep only the first band of ink rows from the top (the rank), dropping the suit pip below a blank row. */
    static boolean[] topBand(boolean[] m, int w, int h) {
        if (m == null) return null;
        int start = -1, end = h;
        for (int y = 0; y < h; y++) {
            boolean any = false;
            for (int x = 0; x < w && !any; x++) any = m[y * w + x];
            if (any && start < 0) start = y;
            else if (!any && start >= 0) { end = y; break; }
        }
        if (start < 0) return null;
        boolean[] out = new boolean[m.length];
        System.arraycopy(m, start * w, out, start * w, (end - start) * w);
        return out;
    }

    Card readCard(Frame f, int[] rankBox, int[] suitBox) { return readCard(f, rankBox, suitBox, false); }

    Card readCard(Frame f, int[] rankBox, int[] suitBox, boolean hero) {
        int rw = rankBox[2] - rankBox[0], rh = rankBox[3] - rankBox[1];
        boolean[] raw = inkMask(f, rankBox);
        if (hero) raw = dropTopTouching(raw, rw, rh);
        boolean[] rm = topBand(raw, rw, rh);
        if (rm == null) return null;
        Glyph g = Glyph.fromMask(rm, rw, rh);
        if (g == null) return null;
        Templates.Match mt = templates.match(g);

        // Suit from the colour of the ink (rank + pip are the same colour). Use the darkest half of the ink
        // (the solid core, not the blended edges) and compare its colourfulness with the card's white.
        // Streams/video tint black slightly brown, so "a little colour" still means black.
        java.util.ArrayList<int[]> ink = new java.util.ArrayList<>();
        int[][] boxes = {rankBox, suitBox};
        for (int[] b : boxes) {
            boolean[] m = b == rankBox ? rm : inkMask(f, b);
            if (m == null) continue;
            int w = b[2] - b[0];
            for (int i = 0; i < m.length; i++) if (m[i]) {
                int c = f.get(b[0] + i % w, b[1] + i / w);
                ink.add(new int[]{Frame.v(c), Frame.r(c), Frame.g(c), Frame.b(c)});
            }
        }
        if (ink.size() < 10) return null;
        ink.sort((p, q) -> p[0] - q[0]);
        long R = 0, G = 0, B = 0; int n = Math.max(5, ink.size() / 2);
        for (int i = 0; i < n; i++) { R += ink.get(i)[1]; G += ink.get(i)[2]; B += ink.get(i)[3]; }
        int avg = 0xFF000000 | ((int) (R / n) << 16) | ((int) (G / n) << 8) | (int) (B / n);
        int chroma = Frame.v(avg) - Math.min(Frame.r(avg), Math.min(Frame.g(avg), Frame.b(avg)));
        int face = faceV(f, rankBox);
        char suit;
        if (chroma < face * 0.17f) suit = 's';
        else {
            float hue = Frame.hue(avg);
            if (hue < 35 || hue > 320) suit = 'h';
            else if (hue < 175) suit = 'c';
            else suit = 'd';
        }
        return new Card(mt.rank, suit, mt.confident(), mt.score, g);
    }

    /**
     * Two face-up cards at a seat (showdown), or null. They're big white cards fanned over the player's avatar:
     * find the white area, then the rank in each card's top-left corner (the topmost ink, one per card) with the
     * suit pip right under it, and read them like any other card.
     */
    Card[] shownCards(Frame f, Viewport vp, int seat) {
        int[] r = vp.map(Layout.seatShown(seat));
        int x0 = Math.max(0, r[0]), y0 = Math.max(0, r[1]), x1 = Math.min(f.w, r[2]), y1 = Math.min(f.h, r[3]);
        int w = x1 - x0, h = y1 - y0;
        if (w < 20 || h < 20) return null;
        float sc = vp.w / (float) Layout.REF_W;
        int[] spanL = new int[h], spanR = new int[h], cnt = new int[h];
        int top = -1, bot = -1, minRow = Math.round(40 * sc);
        for (int y = 0; y < h; y++) {
            spanL[y] = w; spanR[y] = -1;
            for (int x = 0; x < w; x++) {
                int c = f.get(x0 + x, y0 + y);
                if (Frame.v(c) > 190 && !Frame.colored(c)) {
                    cnt[y]++;
                    if (x < spanL[y]) spanL[y] = x;
                    spanR[y] = x;
                }
            }
            if (cnt[y] >= minRow) { if (top < 0) top = y; bot = y; }
        }
        if (top < 0) return null;
        int H = bot - top + 1;
        if (H < 115 * sc || H > 220 * sc) return null;                 // a showdown card is ~165 tall
        int whiteRows = 0;
        for (int y = top; y <= bot; y++) if (cnt[y] >= minRow) whiteRows++;
        if (whiteRows < H * 0.8f) return null;

        // ink inside the white part, in the top 45% of the cards
        int bandH = Math.round(H * 0.45f);
        boolean[] ink = new boolean[w * bandH];
        for (int y = 0; y < bandH; y++) {
            int yy = top + y;
            if (yy >= h || spanR[yy] < 0) continue;
            for (int x = spanL[yy] + 1; x < spanR[yy]; x++) {
                int c = f.get(x0 + x, y0 + yy);
                ink[y * w + x] = Frame.colored(c) || Frame.v(c) < 150;
            }
        }
        // connected blobs; ranks are the blobs that start near the top of the cards
        int[] lab = new int[w * bandH];
        int[] stack = new int[w * bandH];
        List<int[]> blobs = new ArrayList<>();      // {minx, miny, maxx, maxy}
        for (int i = 0; i < ink.length; i++) {
            if (!ink[i] || lab[i] != 0) continue;
            int sp = 0; stack[sp++] = i; lab[i] = 1;
            int[] bb = {w, bandH, -1, -1};
            while (sp > 0) {
                int p = stack[--sp];
                int px = p % w, py = p / w;
                bb[0] = Math.min(bb[0], px); bb[1] = Math.min(bb[1], py);
                bb[2] = Math.max(bb[2], px); bb[3] = Math.max(bb[3], py);
                for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) {
                    int qx = px + dx, qy = py + dy;
                    if (qx < 0 || qy < 0 || qx >= w || qy >= bandH) continue;
                    int q = qy * w + qx;
                    if (ink[q] && lab[q] == 0) { lab[q] = 1; stack[sp++] = q; }
                }
            }
            int bh = bb[3] - bb[1] + 1;
            if (bh >= H * 0.12f && bh <= H * 0.36f && bb[1] <= H * 0.20f) blobs.add(bb);
        }
        if (blobs.isEmpty()) return null;
        blobs.sort((p, q) -> p[0] - q[0]);
        // join side-by-side blobs into one rank ("10")
        List<int[]> ranks = new ArrayList<>();
        for (int[] b : blobs) {
            int[] last = ranks.isEmpty() ? null : ranks.get(ranks.size() - 1);
            if (last != null && b[0] - last[2] <= H * 0.06f && Math.abs(b[1] - last[1]) <= H * 0.08f) {
                last[2] = Math.max(last[2], b[2]); last[3] = Math.max(last[3], b[3]); last[1] = Math.min(last[1], b[1]);
            } else ranks.add(b.clone());
        }
        if (ranks.size() < 2) return null;
        Card[] out = new Card[2];
        int pad = Math.max(2, Math.round(4 * sc));
        for (int k = 0; k < 2; k++) {
            int[] b = ranks.get(k);
            int rx0 = x0 + b[0] - pad, ry0 = y0 + top + b[1] - pad, rx1 = x0 + b[2] + pad + 1, ry1 = y0 + top + b[3] + pad + 1;
            int gh = b[3] - b[1] + 1;
            int[] rankBox = {rx0, ry0, rx1, ry1};
            int[] suitBox = {rx0 - pad, ry1, rx1 + pad, ry1 + Math.round(gh * 1.05f)};
            Card c = readCard(f, rankBox, suitBox, false);
            if (c == null) return null;
            out[k] = c;
        }
        if (out[0].rank == out[1].rank && out[0].suit == out[1].suit) return null;
        return out;
    }

        /** Glyph only – used to build templates. */
    public Glyph glyphAt(Frame f, int[] refRankBox) {
        int[] b = Viewport.detect(f).map(refRankBox);
        boolean[] m = topBand(inkMask(f, b), b[2] - b[0], b[3] - b[1]);
        return m == null ? null : Glyph.fromMask(m, b[2] - b[0], b[3] - b[1]);
    }
}
