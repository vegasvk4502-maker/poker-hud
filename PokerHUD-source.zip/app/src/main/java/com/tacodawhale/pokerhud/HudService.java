package com.tacodawhale.pokerhud;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.tacodawhale.pokerhud.core.Advisor;
import com.tacodawhale.pokerhud.core.Danger;
import com.tacodawhale.pokerhud.core.Draws;
import com.tacodawhale.pokerhud.core.Frame;
import com.tacodawhale.pokerhud.core.HandEval;
import com.tacodawhale.pokerhud.core.Layout;
import com.tacodawhale.pokerhud.core.StartingHands;
import com.tacodawhale.pokerhud.core.TableReader;
import com.tacodawhale.pokerhud.core.Viewport;

import java.nio.ByteBuffer;

/** Captures the screen, reads the table and shows the see-through advice panel on top of the game. */
public class HudService extends Service {
    static final String EXTRA_CODE = "code", EXTRA_DATA = "data", ACTION_STOP = "com.tacodawhale.pokerhud.STOP";
    private static final String CHANNEL = "hud";
    private static final long FRAME_MS = 500;

    private MediaProjection projection;
    private volatile VirtualDisplay display;
    private volatile ImageReader reader;
    private HandlerThread thread;
    private Handler worker;
    private final Handler main = new Handler(Looper.getMainLooper());

    private WindowManager wm;
    private LinearLayout panel;
    private WindowManager.LayoutParams lp;
    private TextView tvAction, tvLight, tvNeed, tvChart, tvNuts, tvWarn, tvDraw, tvBluff, tvHero, tvBoard, tvMade, tvInfo;
    private LinearLayout box;              // the advice box (the window also holds the chart badge and table map)
    private FlowRow tags;
    private volatile String bluffText = "";
    private String chartHand = "", chartText = "";   // the chart badge stays for the whole hand
    private int chartColor;
    private GradientDrawable chartBg;
    private TableMapView tableMap;
    private EquityView equityView;
    private volatile boolean showEquity;   // % button: equity box open
    // Tap to peek: ◎ / % pops a table up for a few seconds. While it's up it covers the game, so card reading
    // pauses (the screen capture would see the table instead of the cards) and picks up again once it's gone.
    private static final long PEEK_MS = 8000, RESUME_DELAY_MS = 400;
    private volatile int peekWant;          // 0 none, 1 table map, 2 % box – opens after the next clean read
    private volatile boolean peeking;
    private volatile long resumeAt;
    private final Runnable autoClose = this::closePeek;
    private String equityKey = "";
    private volatile boolean showPlayers;   // ◎ table map showing
    private boolean compact;

    private TableReader tableReader;
    private com.tacodawhale.pokerhud.core.HandTracker tracker;
    private TextNameReader nameReader;
    private final Advisor advisor = new Advisor();
    private String shownKey = "", pendingKey = "";
    private int pendingCount;
    private Advisor.Advice advice;

    private volatile int[] panelRect;      // where the HUD panel is on screen, ignored when finding the game
    private Viewport lock;                 // game area locked onto (where the table reads best)
    private int badFrames;                 // frames in a row where the locked area read poorly
    private long lastSearch;

    private byte[] bytes;
    private int[] argb;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || ACTION_STOP.equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if (projection != null) return START_NOT_STICKY;   // already running

        startForegroundNow();
        int code = intent.getIntExtra(EXTRA_CODE, 0);
        Intent data = Build.VERSION.SDK_INT >= 33
                ? intent.getParcelableExtra(EXTRA_DATA, Intent.class)
                : intent.getParcelableExtra(EXTRA_DATA);
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        projection = data == null ? null : mpm.getMediaProjection(code, data);
        if (projection == null) { stopSelf(); return START_NOT_STICKY; }
        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() { main.post(HudService.this::stopSelf); }
        }, main);

        tableReader = new TableReader(HudState.templates(this));
        tracker = HudState.tracker(this);
        nameReader = new TextNameReader();
        tracker.setNameReader(nameReader);
        thread = new HandlerThread("hud-capture");
        thread.start();
        worker = new Handler(thread.getLooper());

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        Rect bounds = wm.getMaximumWindowMetrics().getBounds();
        int w = bounds.width(), h = bounds.height();
        int dpi = getResources().getDisplayMetrics().densityDpi;
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2);
        display = projection.createVirtualDisplay("pokerhud", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, worker);

        showOverlay();
        HudState.running = true;
        worker.postDelayed(tick, 800);
        return START_NOT_STICKY;
    }

    private void startForegroundNow() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Poker HUD", NotificationManager.IMPORTANCE_LOW));
        PendingIntent stop = PendingIntent.getService(this, 1,
                new Intent(this, HudService.class).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE);
        PendingIntent open = PendingIntent.getActivity(this, 2,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setContentTitle("Poker HUD is running")
                .setContentText("Reading the table. Tap to open, or Stop.")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentIntent(open)
                .addAction(new Notification.Action.Builder(null, "Stop", stop).build())
                .setOngoing(true)
                .build();
        startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
    }

    // ---------- overlay ----------

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private LinearLayout.LayoutParams wrapLp() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    /** A small rounded tag. */
    private TextView pill(float sp, int textColor, int bgColor) {
        TextView t = text(sp, textColor, true);
        GradientDrawable g = new GradientDrawable();
        g.setColor(bgColor);
        g.setCornerRadius(dp(10));
        t.setBackground(g);
        t.setPadding(dp(8), dp(2), dp(8), dp(3));
        t.setVisibility(View.GONE);
        return t;
    }

    private TextView text(float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        t.setShadowLayer(3, 0, 1, 0xFF000000);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private void showOverlay() {
        // The window: the chart badge (its own pill), the table map (when open), then the advice box.
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setGravity(Gravity.END);

        // equity box (% button), on top of everything
        equityView = new EquityView(this);
        GradientDrawable ebg = new GradientDrawable();
        ebg.setColor(0xDD000000);
        ebg.setCornerRadius(dp(12));
        ebg.setStroke(dp(1), 0x55FFFFFF);
        equityView.setBackground(ebg);
        equityView.setVisibility(View.GONE);
        equityView.setOnClickListener(v -> closePeek());   // tap the box to close it
        LinearLayout.LayoutParams elp = wrapLp();
        elp.bottomMargin = dp(4);
        panel.addView(equityView, elp);

        // starting-hand chart badge, in the chart's colour for your hand – stays for the whole hand
        tvChart = text(13, 0xFFFFFFFF, true);
        chartBg = new GradientDrawable();
        chartBg.setCornerRadius(dp(12));
        tvChart.setBackground(chartBg);
        tvChart.setPadding(dp(10), dp(3), dp(10), dp(4));
        tvChart.setVisibility(View.GONE);
        LinearLayout.LayoutParams clp = wrapLp();
        clp.bottomMargin = dp(4);
        panel.addView(tvChart, clp);

        // table map: every player in their seat with their type and tip (◎ button opens / closes it)
        tableMap = new TableMapView(this);
        GradientDrawable mbg = new GradientDrawable();
        mbg.setColor(0xDD000000);
        mbg.setCornerRadius(dp(12));
        mbg.setStroke(dp(1), 0x55FFFFFF);
        tableMap.setBackground(mbg);
        tableMap.setVisibility(View.GONE);
        tableMap.setOnClickListener(v -> closePeek());     // tap the map to close it
        LinearLayout.LayoutParams mlp = wrapLp();
        mlp.bottomMargin = dp(4);
        panel.addView(tableMap, mlp);

        // the advice box
        box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(10), dp(6), dp(10), dp(8));
        box.setMinimumWidth(dp(290));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0x99000000);              // see-through black
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), 0x55FFFFFF);
        box.setBackground(bg);
        panel.addView(box, wrapLp());

        // row 1: action + %, call light with the % needed, table button
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        tvAction = text(24, 0xFFFFFFFF, true);
        tvAction.setText("Poker HUD");
        LinearLayout lightCol = new LinearLayout(this);
        lightCol.setOrientation(LinearLayout.VERTICAL);
        lightCol.setPadding(dp(12), 0, 0, 0);
        tvLight = text(13, 0xFFFFFFFF, true);
        tvNeed = text(11, 0xFFBBBBBB, false);
        lightCol.addView(tvLight);
        lightCol.addView(tvNeed);
        View spacer = new View(this);
        TextView tableBtn = text(18, 0xFFFFFFFF, true);
        tableBtn.setText("\u25CE");
        GradientDrawable bbg = new GradientDrawable();
        bbg.setColor(0xFF4A3A7A);
        bbg.setCornerRadius(dp(8));
        bbg.setStroke(dp(1), 0x88FFFFFF);
        tableBtn.setBackground(bbg);
        tableBtn.setPadding(dp(9), dp(1), dp(9), dp(3));
        tableBtn.setOnClickListener(v -> toggleTableMap());
        LinearLayout.LayoutParams blp = wrapLp();
        blp.leftMargin = dp(10);
        TextView eqBtn = text(17, 0xFFFFFFFF, true);
        eqBtn.setText("%");
        GradientDrawable ebb = new GradientDrawable();
        ebb.setColor(0xFF005A6E);
        ebb.setCornerRadius(dp(8));
        ebb.setStroke(dp(1), 0x88FFFFFF);
        eqBtn.setBackground(ebb);
        eqBtn.setPadding(dp(10), dp(1), dp(10), dp(3));
        eqBtn.setOnClickListener(v -> toggleEquity());
        LinearLayout.LayoutParams elb = wrapLp();
        elb.leftMargin = dp(6);
        top.addView(tvAction);
        top.addView(lightCol);
        top.addView(spacer, new LinearLayout.LayoutParams(0, 1, 1f));
        top.addView(tableBtn, blp);
        top.addView(eqBtn, elb);
        box.addView(top, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        // row 2: your cards, the board, what you've made
        LinearLayout cardsRow = new LinearLayout(this);
        cardsRow.setOrientation(LinearLayout.HORIZONTAL);
        cardsRow.setGravity(Gravity.CENTER_VERTICAL);
        tvHero = text(16, 0xFFFFFFFF, true);
        tvHero.setText("Looking for the table\u2026");
        tvBoard = text(14, 0xFFDDDDDD, false);
        tvBoard.setPadding(dp(10), 0, 0, 0);
        tvMade = pill(12, 0xFFFFFFFF, 0xFF3C3C3C);
        LinearLayout.LayoutParams mdp = wrapLp();
        mdp.leftMargin = dp(10);
        cardsRow.addView(tvHero);
        cardsRow.addView(tvBoard);
        cardsRow.addView(tvMade, mdp);
        LinearLayout.LayoutParams crp = wrapLp();
        crp.topMargin = dp(4);
        box.addView(cardsRow, crp);

        // row 3: tags – the nuts (gold), danger warnings (amber), draws (teal)
        tags = new FlowRow(this, dp(6));
        tvNuts = pill(12, 0xFFFFD84A, 0xCC0B4A1F);
        tvNuts.setText("\uD83D\uDD12 The nuts");
        tvWarn = pill(12, 0xFFFFC23D, 0xCC6B2A00);
        tvDraw = pill(12, 0xFF3DEBFF, 0xCC00444F);
        tvBluff = pill(12, 0xFFFF8CF2, 0xCC4A0F45);   // bluff / steal spots: pink on dark purple
        tags.addView(tvBluff);
        tags.addView(tvNuts);
        tags.addView(tvWarn);
        tags.addView(tvDraw);
        LinearLayout.LayoutParams tgp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        tgp.topMargin = dp(6);
        box.addView(tags, tgp);

        // row 4: one short grey line
        tvInfo = text(11, 0xFFBBBBBB, false);
        LinearLayout.LayoutParams ilp = wrapLp();
        ilp.topMargin = dp(6);
        box.addView(tvInfo, ilp);

        lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        // starts in the bottom-right corner, below the game; wherever you drag it is remembered between runs
        lp.gravity = Gravity.BOTTOM | Gravity.END;
        SharedPreferences pos = getSharedPreferences("pokerhud", MODE_PRIVATE);
        lp.x = pos.getInt("panel_br_x", dp(2));
        lp.y = pos.getInt("panel_br_y", dp(4));
        box.setOnTouchListener(new View.OnTouchListener() {
            float sx, sy; int ox, oy; boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = e.getRawX(); sy = e.getRawY(); ox = lp.x; oy = lp.y; moved = false; return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) (e.getRawX() - sx), dy = (int) (e.getRawY() - sy);
                        if (Math.abs(dx) + Math.abs(dy) > dp(6)) moved = true;
                        if (moved) {
                            lp.x = Math.max(0, ox - dx);   // anchored bottom-right, so directions flip
                            lp.y = Math.max(0, oy - dy);
                            wm.updateViewLayout(panel, lp);
                            panel.post(HudService.this::updatePanelRect);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (moved) {
                            getSharedPreferences("pokerhud", MODE_PRIVATE).edit()
                                    .putInt("panel_br_x", lp.x).putInt("panel_br_y", lp.y).apply();
                        } else {           // tapping the box also opens / closes the table map
                            toggleTableMap();
                        }
                        return true;
                }
                return false;
            }
        });
        wm.addView(panel, lp);
        panel.getViewTreeObserver().addOnGlobalLayoutListener(this::updatePanelRect);
    }

    private void updatePanelRect() {
        if (panel == null || !panel.isAttachedToWindow()) return;
        int[] loc = new int[2];
        panel.getLocationOnScreen(loc);
        panelRect = new int[]{loc[0], loc[1], loc[0] + panel.getWidth(), loc[1] + panel.getHeight()};
    }

    /** Phone rotated: resize the capture so it matches the new orientation. */
    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        Handler h = worker;
        if (h == null || wm == null) return;
        Rect b = wm.getMaximumWindowMetrics().getBounds();
        int w = b.width(), hh = b.height();
        int dpi = getResources().getDisplayMetrics().densityDpi;
        h.post(() -> {
            VirtualDisplay d = display;
            ImageReader old = reader;
            if (d == null || old == null || (old.getWidth() == w && old.getHeight() == hh)) return;
            try {
                ImageReader nr = ImageReader.newInstance(w, hh, PixelFormat.RGBA_8888, 2);
                d.resize(w, hh, dpi);
                d.setSurface(nr.getSurface());
                reader = nr;
                old.close();
            } catch (Exception ignored) { }
        });
    }

    // ---------- capture loop ----------

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            try {
                Image img = reader.acquireLatestImage();
                if (img != null) {
                    try { process(img); } finally { img.close(); }
                }
            } catch (Exception e) {
                post("Error", e.getClass().getSimpleName() + ": " + e.getMessage(), "", "", 0xFFFFFFFF);
            }
            if (worker != null) worker.postDelayed(this, FRAME_MS);
        }
    };

    private void process(Image img) {
        if (peeking || System.currentTimeMillis() < resumeAt) return;   // a table is covering the game
        try {
            readFrame(img);
        } finally {
            if (peekWant != 0) openPeek();
        }
    }

    private void readFrame(Image img) {
        int w = img.getWidth(), h = img.getHeight();
        Image.Plane plane = img.getPlanes()[0];
        ByteBuffer buf = plane.getBuffer();
        int ps = plane.getPixelStride(), rs = plane.getRowStride();
        if (bytes == null || bytes.length < buf.remaining()) bytes = new byte[buf.remaining()];
        int n = buf.remaining();
        buf.get(bytes, 0, n);
        if (argb == null || argb.length != w * h) argb = new int[w * h];
        for (int y = 0; y < h; y++) {
            int row = y * rs, o = y * w;
            for (int x = 0; x < w; x++) {
                int i = row + x * ps;
                if (i + 2 >= n) break;
                argb[o + x] = 0xFF000000 | ((bytes[i] & 0xff) << 16) | ((bytes[i + 1] & 0xff) << 8) | (bytes[i + 2] & 0xff);
            }
        }
        Frame frame = new Frame(w, h, argb);
        boolean landscape = w > h;
        // Find the game inside the screen: full screen, or shrunk inside a browser / AirDroid window.
        // Find the game on screen and stay locked on it. Re-search only when the locked area stops reading well
        // for a few seconds (e.g. the browser was scrolled or zoomed), at most every 3 s.
        TableReader.State st = null;
        Viewport vp = lock;
        float lockQ = -1e9f;
        if (lock != null) {
            st = tableReader.read(frame, lock);
            lockQ = st.quality();
            if (lockQ >= 4) badFrames = 0; else badFrames++;
        }
        long now = System.currentTimeMillis();
        if ((lock == null || badFrames >= 6) && now - lastSearch > 3000) {
            lastSearch = now;
            Object[] r = Viewport.search(frame, panelRect, tableReader);
            float q = (Float) r[1];
            if (q >= 5f && q > lockQ) {          // only move to an area that reads the table better
                lock = (Viewport) r[0];
                vp = lock;
                st = tableReader.read(frame, lock);
                badFrames = 0;
            }
        }
        if (st == null) {
            if (vp == null) vp = Viewport.detect(frame, panelRect);
            st = tableReader.read(frame, vp);
        }
        for (TableReader.Card c : st.hero) if (!c.sure) HudState.addUnknown(c.glyph);
        for (TableReader.Card c : st.board) if (!c.sure) HudState.addUnknown(c.glyph);

        // remember who's who and what everyone did this hand; save player history / hand log when it changes
        tracker.update(st, frame, vp, System.currentTimeMillis());
        if (tracker.takeDirty()) HudState.save(this);
        java.util.List<Double> preL = new java.util.ArrayList<>();
        java.util.List<Integer> postL = new java.util.ArrayList<>();
        java.util.List<String> labels = new java.util.ArrayList<>();
        tracker.ranges(st, preL, postL, labels);
        updatePlayerReads(st);

        int deciding = st.decidingSeat();
        String turn = st.heroTurn ? "\u25B6 YOUR TURN"
                : deciding >= 0 ? Layout.SEAT_NAMES[deciding] + " deciding" : "";

        String board = cardsText(st.board);
        boolean boardOk = st.board.size() == 0 || st.board.size() >= 3;
        if (st.hero.size() != 2 || !boardOk) {
            pendingKey = ""; pendingCount = 0;
            String cards = st.hero.size() == 2 ? cardsText(st.hero) : "No cards";
            if (st.hero.isEmpty() && st.board.isEmpty() && st.opponentsInHand() == 0)
                cards = lock == null ? "Looking for the table\u2026" : "Waiting for the next hand\u2026";
            if (st.hero.isEmpty()) { chartHand = ""; chartText = ""; }
            postStatus(cards, board, turn);
            HudState.lastStatus = cards;
            if (equityView != null && !equityKey.isEmpty()) {
                equityKey = "";
                main.post(() -> { equityView.empty = true; equityView.hand = ""; equityView.refresh(); });
            }
            return;
        }

        int opp = Math.max(1, st.opponentsInHand());
        double[] pre = new double[opp];
        int[] post = new int[opp];
        java.util.Arrays.fill(pre, 1.0);
        for (int i = 0; i < Math.min(opp, preL.size()); i++) { pre[i] = preL.get(i); post[i] = postL.get(i); }
        int position = st.heroPosition();
        String key = cardsText(st.hero) + "|" + board + "|" + opp + "|" + java.util.Arrays.toString(pre)
                + java.util.Arrays.toString(post) + "|" + position;
        // wait for two identical reads so dealing animations don't flicker the advice
        if (key.equals(pendingKey)) pendingCount++; else { pendingKey = key; pendingCount = 1; }
        if (pendingCount >= 2 && !key.equals(shownKey)) {
            advice = advisor.advise(st.hero, st.board, pre, post, position, 8000);
            shownKey = key;
            tracker.noteAdvice(advice, opp);
        }
        if (advice == null || !key.equals(shownKey)) return;

        int color = advice.action.equals("RAISE") ? 0xFF4CFF6A : advice.action.equals("CALL") ? 0xFFFFD84A : 0xFFFF5A4A;
        String action = advice.action + "  " + Math.round(advice.equity * 100) + "%";
        String pos = Advisor.positionName(position);
        String info = "vs " + opp + (pos.isEmpty() ? "" : "  \u00B7  " + pos) + (turn.isEmpty() ? "" : "  \u00B7  " + turn);
        // call light: green = your chance is enough to call, red = check or fold
        boolean go = advice.equity >= advice.callNeed;
        String light = go ? "\u25CF call OK" : "\u25CF check / fold";
        String need = "need " + Math.round(advice.callNeed * 100) + "%";
        int lightColor = go ? 0xFF35E05A : 0xFFFF4040;
        int[] hc = new int[2], bc = new int[st.board.size()];
        for (int i = 0; i < 2; i++) hc[i] = HandEval.parse(st.hero.get(i).text());
        for (int i = 0; i < bc.length; i++) bc[i] = HandEval.parse(st.board.get(i).text());
        // danger warnings for hands the board makes possible that beat yours
        StringBuilder warn = new StringBuilder();
        for (String d : Danger.warnings(hc, bc)) warn.append(warn.length() > 0 ? "  \u00B7  " : "\u26A0 ").append(d);
        // draw info: outs and the chance of hitting
        String drawInfo = Draws.describe(hc, bc);
        String draw = drawInfo.isEmpty() ? "" : "$ " + drawInfo.replace(": ", " ").replace(" outs, ", " outs \u00B7 ")
                .replace(" out, ", " out \u00B7 ").replace(" by the river", "").replace(" on the river", "");
        boolean nuts = Danger.isNuts(hc, bc);
        // bluff / steal spots (only on your turn)
        int[] sids = tracker.seatPlayers();
        String[] seatTypes = new String[sids.length];
        com.tacodawhale.pokerhud.core.PlayerBook sbook = HudState.book(this);
        for (int i = 0; i < sids.length; i++) {
            com.tacodawhale.pokerhud.core.PlayerBook.Player p = sids[i] < 0 ? null : sbook.byId(sids[i]);
            if (p != null) seatTypes[i] = com.tacodawhale.pokerhud.core.PlayerBook.shortRead(p)[0];
        }
        String spot = com.tacodawhale.pokerhud.core.Spots.bluff(st, position, seatTypes,
                advice.action.equals("FOLD"), StartingHands.group(hc[0], hc[1]));
        if (!spot.isEmpty()) spot = (spot.startsWith("No bluff") ? "\u270B " : "\uD83C\uDFAD ") + spot;
        // chart badge: worked out before the flop (seat + whether anyone raised) and kept for the whole hand
        String heroKey = cardsText(st.hero);
        if (bc.length == 0 || !heroKey.equals(chartHand)) {
            char g = StartingHands.group(hc[0], hc[1]);
            boolean raised = false;
            if (bc.length == 0) for (String l : labels) if (l.contains("raised")) raised = true;
            String v = StartingHands.verdict(g, position, raised);
            chartHand = heroKey;
            chartText = "\u2605 " + StartingHands.shortName(hc[0], hc[1]) + "  \u00B7  " + StartingHands.groupName(g)
                    + (v.isEmpty() ? "" : "  \u00B7  " + v)
                    + "\n" + StartingHands.rule(g);   // second, smaller line: the chart's rule
            chartColor = StartingHands.color(g);
        }
        bluffText = spot;
        postAdvice(action, color, light, lightColor, need, nuts, warn.toString(), draw,
                cardsText(st.hero), board, advice.madeHand, info);
        if (showEquity && !key.equals(equityKey)) updateEquity(st, pre, post, labels, key);
        HudState.lastStatus = advice.action + " " + Math.round(advice.equity * 100) + "% · " + cardsText(st.hero) + " " + board;
    }

    private void toggleEquity() { requestPeek(2); }

    private void toggleTableMap() { requestPeek(1); }

    /** Tap ◎ / %: close whatever is open; if it wasn't this one, open it after one more fresh read of the game. */
    private void requestPeek(int which) {
        boolean wasThis = (which == 1 && showPlayers) || (which == 2 && showEquity);
        boolean anyOpen = peeking || showPlayers || showEquity;
        closePeek();
        if (wasThis) return;
        if (which == 2) { showEquity = true; equityKey = ""; }   // work out the % box on that read
        peekWant = which;
        if (anyOpen) resumeAt = 0;                                // switching tables: read right away
        // the screen only sends a new picture when something moves – if nothing has, open it anyway
        main.postDelayed(() -> { if (peekWant == which && !peeking) openPeek(); }, 700);
    }

    /** Called on the reading thread right after a clean read: show the table and pause reading. */
    private void openPeek() {
        final int which = peekWant;
        peekWant = 0;
        peeking = true;
        main.post(() -> {
            if (which == 1) { showPlayers = true; if (tableMap != null) tableMap.setVisibility(View.VISIBLE); }
            if (which == 2 && equityView != null) equityView.setVisibility(View.VISIBLE);
            main.removeCallbacks(autoClose);
            main.postDelayed(autoClose, PEEK_MS);
        });
    }

    /** Hide the tables and start reading the game again (after a short wait so the last frame is clean). */
    private void closePeek() {
        main.removeCallbacks(autoClose);
        peekWant = 0;
        showPlayers = false;
        showEquity = false;
        equityKey = "";
        resumeAt = System.currentTimeMillis() + RESUME_DELAY_MS;
        peeking = false;
        Runnable hide = () -> {
            if (tableMap != null) tableMap.setVisibility(View.GONE);
            if (equityView != null) equityView.setVisibility(View.GONE);
        };
        if (Looper.myLooper() == Looper.getMainLooper()) hide.run(); else main.post(hide);
    }

    /** Work out the detailed equity for the % box (only while it's open) and show it. */
    private void updateEquity(TableReader.State st, double[] pre, int[] post, java.util.List<String> labels, String key) {
        equityKey = key;
        com.tacodawhale.pokerhud.core.EquityBreakdown r =
                com.tacodawhale.pokerhud.core.EquityBreakdown.compute(advisor, st.hero, st.board, pre, post, 8000);
        // opponent names in the same order as the ranges: seats still holding cards
        int[] ids = tracker.seatPlayers();
        com.tacodawhale.pokerhud.core.PlayerBook book = HudState.book(this);
        java.util.List<String> names = new java.util.ArrayList<>(), acts = new java.util.ArrayList<>();
        java.util.List<String> types = new java.util.ArrayList<>(), raiseTxt = new java.util.ArrayList<>();
        java.util.List<String> shownTxt = new java.util.ArrayList<>();
        int[] nowRaises = tracker.seatRaises(st);
        java.util.List<Character> actCodes = new java.util.ArrayList<>();
        int li = 0;
        for (int i = 0; i < st.seats.length; i++) {
            if (st.seats[i] == TableReader.SeatStatus.EMPTY_OR_OUT) continue;
            com.tacodawhale.pokerhud.core.PlayerBook.Player p = ids[i] < 0 ? null : book.byId(ids[i]);
            names.add(p != null ? p.name : Layout.SEAT_NAMES[i]);
            types.add(p != null ? com.tacodawhale.pokerhud.core.PlayerBook.shortRead(p)[0] : null);
            raiseTxt.add(raiseText(nowRaises[i], p));
            shownTxt.add(com.tacodawhale.pokerhud.core.PlayerBook.lastShown(p));
            actCodes.add(st.actions[i]);
            String l = li < labels.size() ? labels.get(li) : "";
            int a = l.indexOf('('), b = l.indexOf(')');
            acts.add(a >= 0 && b > a ? l.substring(a + 1, b) : "");
            li++;
        }
        int n = Math.min(names.size(), r.perOpponent.length);
        final String[] on = names.subList(0, n).toArray(new String[0]);
        final String[] oa = acts.subList(0, n).toArray(new String[0]);
        final double[] oe = java.util.Arrays.copyOf(r.perOpponent, n);
        final String[] ot = new String[n], adv = new String[n], kind = new String[n];
        final String[] rx = raiseTxt.subList(0, n).toArray(new String[0]);
        final String[] sx = shownTxt.subList(0, n).toArray(new String[0]);
        for (int i = 0; i < n; i++) {
            ot[i] = types.get(i);
            // what they did: this round's label, or what the hand memory says (e.g. "raised pre")
            char act = actCodes.get(i);
            if (act != 'R' && act != 'C' && act != 'K') {
                String l = oa[i];
                act = l.startsWith("raised") ? 'R' : l.startsWith("called") ? 'C' : '-';
            }
            String[] v = com.tacodawhale.pokerhud.core.Spots.vsPlayer(oe[i], act, ot[i], st.board.size());
            adv[i] = v[0];
            kind[i] = v[1];
        }
        final String[] lt = new String[r.loseCats.length];
        for (int i = 0; i < lt.length; i++)
            lt[i] = com.tacodawhale.pokerhud.core.EquityBreakdown.catName(r.loseCats[i]) + " " + Math.round(r.loseShares[i] * 100) + "%";
        final String next = r.unseen == 0 ? "" : r.helps + " of " + r.unseen + " cards ("
                + Math.round(100.0 * r.helps / r.unseen) + "%)";
        final String hand = cardsText(st.hero) + (st.board.isEmpty() ? "" : "  |  " + cardsText(st.board));
        final double w = r.win, t = r.tie, lo = r.lose;
        main.post(() -> {
            if (equityView == null) return;
            equityView.empty = false;
            equityView.hand = hand;
            equityView.win = w; equityView.tie = t; equityView.lose = lo;
            equityView.oppNames = on; equityView.oppActions = oa; equityView.oppEquity = oe;
            equityView.oppTypes = ot; equityView.oppAdvice = adv; equityView.oppKind = kind;
            equityView.oppRaises = rx;
            equityView.oppShown = sx;
            equityView.loseTo = lt;
            equityView.nextCard = next;
            equityView.refresh();
        });
    }

    /** e.g. "raised 2× now · 14 total" ("" when they've never raised). */
    private static String raiseText(int now, com.tacodawhale.pokerhud.core.PlayerBook.Player p) {
        int total = (p == null ? 0 : p.totalRaises()) + now;
        if (total == 0) return "";
        return now > 0 ? "raised " + now + "\u00D7 now \u00B7 " + total + " total"
                       : total + (total == 1 ? " raise" : " raises") + " total";
    }

    /** Fill the table map: each seat's player, type and tip; a red dot for players still in the hand. */
    private void updatePlayerReads(TableReader.State st) {
        int[] ids = tracker.seatPlayers();
        com.tacodawhale.pokerhud.core.PlayerBook book = HudState.book(this);
        final String[] n = new String[6], t = new String[6], tp = new String[6], rz = new String[6], sh = new String[6];
        int[] nowR = tracker.seatRaises(st);
        final int[] col = new int[6];
        final boolean[] in = new boolean[6];
        String pos = Advisor.positionName(st.heroPosition());
        String[] me = HudState.heroStats(this).read();
        n[0] = "You" + (pos.isEmpty() ? "" : " \u00B7 " + pos.replace(" position", ""));
        t[0] = me[0];
        tp[0] = HudState.heroStats(this).shortTip();
        col[0] = me[0].equals("Solid") ? 0xFF4CFF6A : me[0].equals("A bit loose") ? 0xFFFFA43D
                : me[0].equals("Too loose") ? 0xFFFF5A4A : me[0].equals("Very tight") ? 0xFF9FB4C8 : 0xFFAAAAAA;
        for (int i = 0; i < ids.length; i++) {
            in[i + 1] = st.seats[i] != TableReader.SeatStatus.EMPTY_OR_OUT;
            com.tacodawhale.pokerhud.core.PlayerBook.Player p = ids[i] < 0 ? null : book.byId(ids[i]);
            if (p == null) {
                // every seat shows: "reading name…" while someone's there but the name isn't read yet, else empty
                boolean someone = in[i + 1] || st.actions[i] != '-';
                n[i + 1] = someone ? "?" : "empty";
                t[i + 1] = someone ? "reading name\u2026" : null;
                col[i + 1] = 0xFF888888;
                continue;
            }
            String[] r = com.tacodawhale.pokerhud.core.PlayerBook.shortRead(p);
            n[i + 1] = p.name;
            rz[i + 1] = raiseText(nowR[i], p);
            sh[i + 1] = com.tacodawhale.pokerhud.core.PlayerBook.lastShown(p);
            t[i + 1] = r[0];
            tp[i + 1] = r[1];
            col[i + 1] = com.tacodawhale.pokerhud.core.PlayerBook.typeColor(r[0]);
        }
        main.post(() -> {
            if (tableMap == null) return;
            System.arraycopy(n, 0, tableMap.names, 0, 6);
            System.arraycopy(t, 0, tableMap.tags, 0, 6);
            System.arraycopy(tp, 0, tableMap.tips, 0, 6);
            System.arraycopy(rz, 0, tableMap.raises, 0, 6);
            System.arraycopy(sh, 0, tableMap.shown, 0, 6);
            System.arraycopy(col, 0, tableMap.tagColors, 0, 6);
            System.arraycopy(in, 0, tableMap.inHand, 0, 6);
            tableMap.setVisibility(showPlayers ? View.VISIBLE : View.GONE);
            tableMap.invalidate();
        });
    }

    private static boolean found(TableReader.State st) {
        return !st.hero.isEmpty() || !st.board.isEmpty() || st.opponentsInHand() > 0;
    }

    private static String cardsText(java.util.List<TableReader.Card> cs) {
        StringBuilder sb = new StringBuilder();
        for (TableReader.Card c : cs) {
            if (sb.length() > 0) sb.append(' ');
            sb.append(c.pretty());
        }
        return sb.toString();
    }

    /** No advice right now (no cards, waiting, looking for the table). */
    private void postStatus(String cards, String board, String info) {
        bluffText = "";
        postAdvice("\u2014", 0xFFAAAAAA, "", 0, "", false, "", "", cards, board, "", info);
    }

    private void post(String title, String msg, String a, String b, int color) {   // errors
        postAdvice(title, color, "", 0, "", false, "", "", msg, "", "", "");
    }

    private void postAdvice(String action, int color, String light, int lightColor, String need, boolean nuts,
                            String warn, String draw, String hero, String board, String made, String info) {
        final String chart = chartText;
        final int chartCol = chartColor;
        final String bluff = bluffText;
        main.post(() -> {
            if (panel == null) return;
            tvAction.setText(action);
            tvAction.setTextColor(color);
            tvLight.setText(light);
            tvLight.setTextColor(lightColor);
            tvLight.setVisibility(light.isEmpty() ? View.GONE : View.VISIBLE);
            tvNeed.setText(need);
            tvNeed.setVisibility(need.isEmpty() ? View.GONE : View.VISIBLE);
            tvHero.setText(hero);
            tvBoard.setText(board);
            tvBoard.setVisibility(board.isEmpty() ? View.GONE : View.VISIBLE);
            tvMade.setText(made);
            tvMade.setVisibility(made.isEmpty() ? View.GONE : View.VISIBLE);
            tvNuts.setVisibility(nuts ? View.VISIBLE : View.GONE);
            tvWarn.setText(warn);
            tvWarn.setVisibility(warn.isEmpty() ? View.GONE : View.VISIBLE);
            tvDraw.setText(draw);
            tvDraw.setVisibility(draw.isEmpty() ? View.GONE : View.VISIBLE);
            tvBluff.setText(bluff);
            tvBluff.setVisibility(bluff.isEmpty() ? View.GONE : View.VISIBLE);
            tags.setVisibility(nuts || !warn.isEmpty() || !draw.isEmpty() || !bluff.isEmpty() ? View.VISIBLE : View.GONE);
            tvInfo.setText(info);
            tvInfo.setVisibility(info.isEmpty() ? View.GONE : View.VISIBLE);
            // chart badge (dark text on the light yellow / green groups, white on the darker ones)
            // first line: your hand and what to do; second line (smaller, not bold): the chart's rule
            int nl = chart.indexOf('\n');
            if (nl > 0) {
                android.text.SpannableString sp = new android.text.SpannableString(chart);
                sp.setSpan(new android.text.style.RelativeSizeSpan(0.82f), nl + 1, chart.length(), 0);
                sp.setSpan(new android.text.style.StyleSpan(Typeface.NORMAL), nl + 1, chart.length(), 0);
                tvChart.setText(sp);
            } else tvChart.setText(chart);
            chartBg.setColor(chartCol);
            boolean light2 = chartCol == 0xFFC9A227 || chartCol == 0xFF4CAF50;
            tvChart.setTextColor(light2 ? 0xFF111111 : 0xFFFFFFFF);
            tvChart.setShadowLayer(light2 ? 0 : 3, 0, 1, 0xFF000000);
            tvChart.setVisibility(chart.isEmpty() ? View.GONE : View.VISIBLE);
        });
    }

    @Override
    public void onDestroy() {
        HudState.running = false;
        HudState.lastStatus = "HUD stopped";
        main.removeCallbacks(autoClose);
        if (panel != null && wm != null) { try { wm.removeView(panel); } catch (Exception ignored) { } panel = null; }
        final VirtualDisplay d = display; final ImageReader r = reader;
        display = null; reader = null;
        if (worker != null) {
            Handler h = worker;
            worker = null;                       // stops the loop from re-posting
            h.removeCallbacksAndMessages(null);
            h.post(() -> {                       // release on the capture thread, after any frame in progress
                if (d != null) d.release();
                if (r != null) r.close();
            });
        }
        if (thread != null) thread.quitSafely();
        if (projection != null) { try { projection.stop(); } catch (Exception ignored) { } projection = null; }
        if (tracker != null) tracker.setNameReader(null);
        if (nameReader != null) { try { nameReader.close(); } catch (Exception ignored) { } nameReader = null; }
        super.onDestroy();
    }
}
