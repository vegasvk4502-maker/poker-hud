package com.tacodawhale.pokerhud.core;

import java.util.List;
import java.util.Random;

/**
 * Monte-Carlo equity against the opponents still holding cards, turned into FOLD / CALL / RAISE.
 * The app can't read bet sizes, so the advice is based on hand strength vs. the number of opponents.
 */
public final class Advisor {

    public static final class Advice {
        public final String action;      // FOLD, CALL, RAISE
        public final double equity;      // 0..1
        public final String madeHand;    // e.g. "Pair" (empty pre-flop)
        public final String note;
        public final double callNeed;    // equity needed to call (green light at or above)
        public final double raiseNeed;   // equity needed to raise
        Advice(String a, double e, String m, String n, double c, double r) {
            action = a; equity = e; madeHand = m; note = n; callNeed = c; raiseNeed = r;
        }
    }

    private final Random rnd = new Random();

    /** Share of all starting hands a player who raised is assumed to hold (the strongest 20%). */
    public static final double RAISER_RANGE = 0.20;
    /** Share of raises after the flop assumed to be bluffs (any two cards). */
    public static final double BLUFF_SHARE = 0.25;
    /** Share of all starting hands a player who called before the flop is assumed to hold. */
    public static final double CALLER_RANGE = 0.50;
    /** Share of calls after the flop assumed to be with nothing (any two cards). */
    public static final double CALLER_LOOSE_SHARE = 0.35;

    public Advice advise(List<TableReader.Card> hero, List<TableReader.Card> board, int opponents, int iterations) {
        return advise(hero, board, opponents, 0, iterations);
    }

    /**
     * @param raisers how many of the opponents raised on the current street. Before the flop they're dealt only
     *                strong starting hands; after it, only hands that are strong on this board.
     */
    public Advice advise(List<TableReader.Card> hero, List<TableReader.Card> board, int opponents, int raisers,
                         int iterations) {
        return advise(hero, board, opponents, raisers, 0, iterations);
    }

    public Advice advise(List<TableReader.Card> hero, List<TableReader.Card> board, int opponents, int raisers,
                         int callers, int iterations) {
        return advise(hero, board, opponents, raisers, callers, -1, iterations);
    }

    /**
     * Advice with a range for each opponent still in the hand.
     * @param preFrac share of starting hands each opponent is assumed to hold (1 = any two cards)
     * @param post    each opponent's action after the flop: 2 raised, 1 called, 0 checked / nothing
     */
    public Advice advise(List<TableReader.Card> hero, List<TableReader.Card> board, double[] preFrac, int[] post,
                         int position, int iterations) {
        int opp = Math.max(1, Math.min(5, preFrac.length));
        int[] h = new int[2];
        for (int i = 0; i < 2; i++) h[i] = HandEval.parse(hero.get(i).text());
        int[] b = new int[board.size()];
        for (int i = 0; i < b.length; i++) b[i] = HandEval.parse(board.get(i).text());
        int[] minScore = new int[opp];
        int[] postRange = new int[opp];
        for (int i = 0; i < opp; i++) {
            double fr = i < preFrac.length ? preFrac[i] : 1.0;
            minScore[i] = fr >= 0.999 ? Integer.MIN_VALUE : cutoff(fr);
            postRange[i] = b.length >= 3 && i < post.length ? post[i] : 0;
        }
        double eq = equity(h, b, minScore, postRange, iterations);
        return finish(h, b, eq, opp, position);
    }

    /** Short name for a position (see {@link TableReader.State#heroPosition()}). */
    public static String positionName(int pos) {
        switch (pos) {
            case 0: return "Late position (button)";
            case 5: return "Late position";
            case 4: return "Middle position";
            case 3: return "Early position";
            case 1: return "Small blind";
            case 2: return "Big blind";
            default: return "";
        }
    }

    /**
     * How much to scale the call / raise bars for your position: acting last lets you play more hands,
     * acting first (or from the blinds after the flop) fewer.
     */
    public static double positionFactor(int pos, int boardCards) {
        switch (pos) {
            case 0: case 5: return 0.90;                       // button, cutoff: act last
            case 3: return 1.12;                               // first to act
            case 1: case 2: return boardCards == 0 ? 0.97 : 1.05;  // blinds: money already in, but act first later
            default: return 1.0;
        }
    }

    /**
     * @param callers  how many opponents called on the current street – they're dealt middling hands.
     * @param position your position (0 button … 5 cutoff, -1 unknown) – adjusts the call / raise bars.
     */
    public Advice advise(List<TableReader.Card> hero, List<TableReader.Card> board, int opponents, int raisers,
                         int callers, int position, int iterations) {
        int opp = Math.max(1, Math.min(5, opponents));
        int[] h = new int[2];
        for (int i = 0; i < 2; i++) h[i] = HandEval.parse(hero.get(i).text());
        int[] b = new int[board.size()];
        for (int i = 0; i < b.length; i++) b[i] = HandEval.parse(board.get(i).text());
        // range per opponent: 2 = raised, 1 = called, 0 = anything (checked / unknown)
        int[] range = new int[opp];
        for (int i = 0; i < opp; i++) range[i] = i < raisers ? 2 : i < raisers + callers ? 1 : 0;
        int[] minScore = new int[opp];
        for (int i = 0; i < opp; i++) {
            minScore[i] = b.length > 0 || range[i] == 0 ? Integer.MIN_VALUE
                    : cutoff(range[i] == 2 ? RAISER_RANGE : CALLER_RANGE);
        }
        double eq = equity(h, b, minScore, b.length >= 3 ? range : new int[opp], iterations);
        return finish(h, b, eq, opp, position);
    }

    private Advice finish(int[] h, int[] b, double eq, int opp, int position) {

        String made = "";
        if (b.length >= 3) {
            int[] all = new int[2 + b.length];
            all[0] = h[0]; all[1] = h[1];
            System.arraycopy(b, 0, all, 2, b.length);
            made = HandEval.NAMES[HandEval.category(HandEval.eval(all, all.length))];
        }

        double[] need = thresholds(opp, b.length);
        double pf = positionFactor(position, b.length);
        need = new double[]{need[0] * pf, need[1] * pf};
        String action, note;
        if (eq >= need[1]) {
            action = "RAISE";
            note = b.length == 0 ? "Strong starting hand" : b.length < 5 ? "You're ahead – charge them" : "Value bet / raise";
        } else if (eq >= need[0]) {
            action = "CALL";
            note = b.length == 0 ? "Playable – call, don't build the pot"
                    : b.length < 5 ? "Call small bets, careful with big ones" : "Call, don't raise";
        } else {
            action = "FOLD";
            note = "Check if it's free";
        }
        return new Advice(action, eq, made, note, need[0], need[1]);
    }

    /**
     * Equity needed to {call, raise} with this many opponents still in. "Fair share" is 1 / (players in hand):
     * calling needs a bit more than that, raising a lot more (or a big absolute edge).
     */
    public static double[] thresholds(int opp, int boardCards) {
        double fair = 1.0 / (Math.max(1, opp) + 1);
        if (boardCards == 0) return new double[]{fair * 1.05, Math.min(fair * 1.45, 0.60)};
        if (boardCards < 5) return new double[]{fair * 1.10, Math.min(fair * 1.65, 0.65)};
        return new double[]{fair * 1.20, Math.min(fair * 1.75, 0.72)};
    }

    /** Equity share (ties split) vs `opp` random hands. */
    public double equity(int[] hero, int[] board, int opp, int iters) {
        int[] any = new int[opp];
        java.util.Arrays.fill(any, Integer.MIN_VALUE);
        return equity(hero, board, any, new int[opp], iters);
    }

    public double equity(int[] hero, int[] board, int[] minScore, int iters) {
        return equity(hero, board, minScore, new int[minScore.length], iters);
    }

    /**
     * Equity share (ties split). Opponent i is dealt only starting hands whose strength score is at least
     * minScore[i] (Integer.MIN_VALUE = any two cards). After the flop, postflop[i] = 2 (raised) deals only hands that
     * are strong on the current board (see {@link #strongOnBoard}) – used for raises after the flop.
     */
    public double equity(int[] hero, int[] board, int[] minScore, int[] postflop, int iters) {
        return equity(hero, board, minScore, postflop, iters, null);
    }

    /** Win / tie / lose counts, and which kind of hand beat you when you lost. */
    public static final class Stats {
        public int wins, ties, losses;
        public final int[] loseTo = new int[9];   // by HandEval category of the hand that beat you
    }

    /** Same as {@link #equity(int[], int[], int[], int[], int)}, also filling in {@code st} if given. */
    public double equity(int[] hero, int[] board, int[] minScore, int[] postflop, int iters, Stats st) {
        int opp = minScore.length;
        boolean[] used = new boolean[52];
        for (int c : hero) used[c] = true;
        for (int c : board) used[c] = true;
        int[] deck = new int[52];
        int dn = 0;
        for (int c = 0; c < 52; c++) if (!used[c]) deck[dn++] = c;

        int need = 5 - board.length;
        int[] mine = new int[7], theirs = new int[7];
        int[] oppCards = new int[2 * opp];
        double total = 0;
        for (int it = 0; it < iters; it++) {
            int pos = 0;
            // opponents first, each from their range (rejection sampling)
            for (int o = 0; o < opp; o++) {
                // after the flop: raisers need a strong hand, callers some piece of the board (with some bluffs / floats)
                int want = postflop[o] == 2 && rnd.nextDouble() >= BLUFF_SHARE ? 2
                        : postflop[o] == 1 && rnd.nextDouble() >= CALLER_LOOSE_SHARE ? 1 : 0;
                for (int tries = 0; ; tries++) {
                    int i = pos + rnd.nextInt(dn - pos);
                    int j = pos + rnd.nextInt(dn - pos - 1);
                    if (j >= i) j++;
                    if (tries < 60) {
                        if (minScore[o] != Integer.MIN_VALUE && chen(deck[i], deck[j]) < minScore[o]) continue;
                        if (want == 2 && !strongOnBoard(deck[i], deck[j], board)) continue;
                        if (want == 1 && !somethingOnBoard(deck[i], deck[j], board)) continue;
                    }
                    int a = deck[i], b = deck[j];
                    // move the two chosen cards to the front of the undealt part
                    int ti = deck[pos]; deck[pos] = deck[i]; deck[i] = ti;
                    int jj = (j == pos) ? i : j;
                    int tj = deck[pos + 1]; deck[pos + 1] = deck[jj]; deck[jj] = tj;
                    oppCards[2 * o] = a; oppCards[2 * o + 1] = b;
                    pos += 2;
                    break;
                }
            }
            // rest of the board
            for (int i = 0; i < need; i++) {
                int j = pos + i + rnd.nextInt(dn - pos - i);
                int t = deck[pos + i]; deck[pos + i] = deck[j]; deck[j] = t;
            }
            int k = 0;
            for (int c : board) { mine[k] = c; theirs[k] = c; k++; }
            for (int i = 0; i < need; i++) { mine[k] = deck[pos + i]; theirs[k] = deck[pos + i]; k++; }
            mine[5] = hero[0]; mine[6] = hero[1];
            int my = HandEval.eval(mine, 7);
            int ties = 0, best = -1;
            boolean lost = false;
            for (int o = 0; o < opp && (st != null || !lost); o++) {
                theirs[5] = oppCards[2 * o]; theirs[6] = oppCards[2 * o + 1];
                int s = HandEval.eval(theirs, 7);
                if (s > my) { lost = true; best = Math.max(best, s); }
                else if (s == my) ties++;
            }
            if (!lost) total += 1.0 / (ties + 1);
            if (st != null) {
                if (lost) { st.losses++; st.loseTo[HandEval.category(best)]++; }
                else if (ties > 0) st.ties++;
                else st.wins++;
            }
        }
        return total / iters;
    }

    /**
     * What a player who raises after the flop usually has: top pair or an overpair, two pair or better
     * (that uses their own cards), or a flush / straight draw while cards are still to come.
     */
    public static boolean strongOnBoard(int c1, int c2, int[] board) {
        int n = board.length;
        int[] all = new int[n + 2];
        System.arraycopy(board, 0, all, 0, n);
        all[n] = c1; all[n + 1] = c2;
        int withHole = HandEval.category(HandEval.eval(all, n + 2));
        int boardOnly = HandEval.category(HandEval.eval(board, n));
        if (withHole >= 2 && withHole > boardOnly) return true;            // two pair+, improved by their cards

        int r1 = c1 >> 2, r2 = c2 >> 2, top = 0;
        for (int c : board) top = Math.max(top, c >> 2);
        if (r1 == r2 && r1 > top) return true;                              // overpair
        if (r1 == top || r2 == top) return true;                            // top pair
        if (withHole > boardOnly && withHole == 1 && r1 == r2 && r1 >= top - 1) return true; // strong pocket pair

        if (n < 5) {                                                         // draws still matter
            for (int s = 0; s < 4; s++) {
                int cnt = 0;
                for (int c : all) if ((c & 3) == s) cnt++;
                if (cnt >= 4 && ((c1 & 3) == s || (c2 & 3) == s)) return true;   // flush draw
            }
            // ranks as bits 1..13 (two..ace), with the ace also at bit 0 for A-2-3-4-5
            int mask = 0, hole = 0;
            for (int c : all) { int r = c >> 2; mask |= 1 << (r + 1); if (r == 12) mask |= 1; }
            for (int r : new int[]{r1, r2}) { hole |= 1 << (r + 1); if (r == 12) hole |= 1; }
            for (int lo = 0; lo + 3 <= 13; lo++) {
                int win = 0xF << lo;
                if ((mask & win) == win && (hole & win) != 0) return true;   // 4 in a row using their card
            }
        }
        return false;
    }

    /** What a caller after the flop usually has: any pair using their cards, a pocket pair, or a draw. */
    public static boolean somethingOnBoard(int c1, int c2, int[] board) {
        if (strongOnBoard(c1, c2, board)) return true;
        int r1 = c1 >> 2, r2 = c2 >> 2;
        if (r1 == r2) return true;                                     // any pocket pair
        for (int c : board) if ((c >> 2) == r1 || (c >> 2) == r2) return true;   // paired the board
        return false;
    }

    /**
     * Starting-hand strength (Chen formula, doubled to stay in whole numbers): pairs and high,
     * suited, connected cards score highest.
     */
    public static int chen(int c1, int c2) {
        int r1 = c1 >> 2, r2 = c2 >> 2;
        int hi = Math.max(r1, r2), lo = Math.min(r1, r2);
        int pts; // doubled
        switch (hi) {
            case 12: pts = 20; break;          // A
            case 11: pts = 16; break;          // K
            case 10: pts = 14; break;          // Q
            case 9:  pts = 12; break;          // J
            default: pts = hi + 2;             // 2..10 -> 1..5 points (doubled: rank value)
        }
        if (r1 == r2) return Math.max(pts * 2, 10);
        if ((c1 & 3) == (c2 & 3)) pts += 4;
        int gap = hi - lo - 1;
        pts -= gap == 0 ? 0 : gap == 1 ? 2 : gap == 2 ? 4 : gap == 3 ? 8 : 10;
        if (gap <= 1 && hi < 10) pts += 2;
        return pts;
    }

    private static int[] sortedScores;

    /** Lowest score still inside the strongest `fraction` of all 1326 starting hands. */
    public static synchronized int cutoff(double fraction) {
        if (sortedScores == null) {
            int[] all = new int[1326];
            int n = 0;
            for (int a = 0; a < 52; a++) for (int b = a + 1; b < 52; b++) all[n++] = chen(a, b);
            java.util.Arrays.sort(all);
            sortedScores = all;
        }
        int idx = (int) Math.round((1 - fraction) * (sortedScores.length - 1));
        return sortedScores[Math.max(0, Math.min(sortedScores.length - 1, idx))];
    }
}
